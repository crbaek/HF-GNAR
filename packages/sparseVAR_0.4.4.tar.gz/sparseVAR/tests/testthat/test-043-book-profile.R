test_that("0.4.3 book profile is vanilla and leaves diagonal unpenalized", {
  z <- sVAR_book_control()
  expect_identical(z$whiten, "none")
  expect_false(z$penalize_diag)
  expect_true(z$standardize)
})

test_that("none whitening produces identity loss weighting", {
  set.seed(1)
  Y <- matrix(rnorm(4 * 80), 4, 80)
  z <- sparseVAR:::.svar_preprocess_043(Y, p = 1, standardize = TRUE, whiten = "none")
  expect_null(z$SigmaInv)
  expect_equal(z$H, diag(4))
})

test_that("diagonal weights are zero when diagonal is unpenalized", {
  W <- sparseVAR:::.make_varp_weights_043(4, 1, penalize_diag = FALSE)
  expect_equal(diag(W), rep(0, 4))
})

test_that("thresholding preserves unpenalized own lags", {
  P <- matrix(c(.05,.01,.02,.03,
                .01,.06,.01,.02,
                .02,.01,.07,.01,
                .01,.02,.01,.08), 4, 4, byrow = TRUE)
  Q <- sVAR_threshold(P, eta = .10, penalize_diag = FALSE, p = 1)
  expect_equal(diag(Q), diag(P))
  expect_true(all(Q[row(Q) != col(Q)] == 0))
})
