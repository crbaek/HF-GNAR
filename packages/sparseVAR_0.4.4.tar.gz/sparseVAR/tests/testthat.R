library(testthat)
library(sparseVAR)
test_check("sparseVAR")
