# sparseVAR 0.4.3: book profile with explicit no-whitening option
#
# Main changes from 0.4.2:
#   * whiten = c("none", "diag", "full")
#   * book defaults: penalize_diag = FALSE, whiten = "none"
#   * post-thresholding respects the diagonal-penalty convention
#   * deprecated updateSigma/sigma_diag_only/diagTF arguments remain supported
#
# The canonical sparse-VAR loss is
#   (1/N) tr{(Y-XB) S (Y-XB)' } + lambda * sum W_ij |B_ij|,
# with S = I for whiten="none".

.resolve_penalize_diag_043 <- function(penalize_diag = FALSE, diagTF = NULL) {
  if (!is.null(diagTF)) {
    warning("'diagTF' is deprecated; use 'penalize_diag'. Mapping: penalize_diag = !diagTF.",
            call. = FALSE)
    penalize_diag <- !isTRUE(diagTF)
  }
  isTRUE(penalize_diag)
}

.resolve_whiten_043 <- function(whiten = c("none", "diag", "full"),
                                updateSigma = NULL,
                                sigma_diag_only = NULL) {
  whiten_missing <- missing(whiten)
  if (!is.null(sigma_diag_only)) {
    warning("'sigma_diag_only' is deprecated; use whiten='diag' or whiten='full'.",
            call. = FALSE)
    whiten <- if (isTRUE(sigma_diag_only)) "diag" else "full"
    whiten_missing <- FALSE
  }
  whiten <- match.arg(whiten, c("none", "diag", "full"))
  if (!is.null(updateSigma)) {
    warning("'updateSigma' is deprecated in 0.4.3; use whiten='none'/'diag'/'full'.",
            call. = FALSE)
    if (!isTRUE(updateSigma)) {
      whiten <- "none"
    } else if (identical(whiten, "none")) {
      if (whiten_missing) whiten <- "full"
      else stop("Conflicting arguments: updateSigma=TRUE with whiten='none'.")
    }
  }
  whiten
}

.make_varp_weights_043 <- function(k, p, penalize_diag = FALSE) {
  W <- matrix(1, nrow = k * p, ncol = k)
  if (!isTRUE(penalize_diag)) {
    for (ell in seq_len(p)) {
      for (j in seq_len(k)) W[(ell - 1L) * k + j, j] <- 0
    }
  }
  W
}

.svar_preprocess_043 <- function(Yt, p = 1, standardize = TRUE,
                                 whiten = c("none", "diag", "full"),
                                 eps_ols = 1e-8) {
  whiten <- match.arg(whiten)
  Yt <- as.matrix(Yt)
  k <- nrow(Yt); TT <- ncol(Yt)
  if (p < 1L || p >= TT) stop("p must satisfy 1 <= p < ncol(Yt).")

  Yc <- Yt - rowMeans(Yt)
  des <- var_design(Yc, p = p)
  Xd <- as.matrix(des$X_design)
  Y <- as.matrix(des$Y_resp)
  N <- nrow(Xd); d <- ncol(Xd)

  X_sd <- rep(1, d); Y_sd <- rep(1, k)
  Xs <- Xd; Ys <- Y
  if (isTRUE(standardize)) {
    X_sd <- apply(Xd, 2, stats::sd)
    Y_sd <- apply(Y, 2, stats::sd)
    X_sd[!is.finite(X_sd) | X_sd <= 0] <- 1
    Y_sd[!is.finite(Y_sd) | Y_sd <= 0] <- 1
    Xs <- sweep(Xd, 2, X_sd, "/")
    Ys <- sweep(Y, 2, Y_sd, "/")
  }

  Sigma_hat <- NULL; SigmaInv <- NULL; H <- diag(k)
  if (!identical(whiten, "none")) {
    B0 <- solve(crossprod(Xs) + diag(eps_ols, d), crossprod(Xs, Ys))
    R0 <- Ys - Xs %*% B0
    Sigma_hat <- crossprod(R0) / N
    if (identical(whiten, "diag")) {
      vv <- pmax(diag(Sigma_hat), 1e-12)
      SigmaInv <- diag(1 / vv, k, k)
      H <- diag(1 / sqrt(vv), k, k)
    } else {
      ee <- eigen((Sigma_hat + t(Sigma_hat)) / 2, symmetric = TRUE)
      dd <- pmax(ee$values, 1e-12)
      H <- ee$vectors %*% diag(1 / sqrt(dd), k, k) %*% t(ee$vectors)
      SigmaInv <- t(H) %*% H
    }
  }

  list(Y_centered = Yc, X_design = Xd, Y_resp = Y,
       Xs = as.matrix(Xs), Ys = as.matrix(Ys),
       X_sd = as.numeric(X_sd), Y_sd = as.numeric(Y_sd),
       N = N, d = d, k = k, p = p,
       whiten = whiten, Sigma_hat = Sigma_hat,
       SigmaInv = SigmaInv, H = H)
}

.theory_lambda_043 <- function(N, q, theory_c = 1) {
  theory_c * sqrt(log(max(q, 2)) / N)
}

.kkt_lambda_grid_fista_043 <- function(X, Y, W, SigmaInv = NULL,
                                       nlambda = 100, lambda_min_ratio = NULL) {
  X <- as.matrix(X); Y <- as.matrix(Y); W <- as.matrix(W)
  n <- nrow(X)
  if (is.null(lambda_min_ratio)) lambda_min_ratio <- if (n > ncol(X)) 1e-4 else 1e-2
  G <- (2 / n) * crossprod(X, Y)
  if (!is.null(SigmaInv)) G <- G %*% SigmaInv
  den <- W; den[den == 0] <- Inf
  lam_max <- max(abs(G) / den, na.rm = TRUE)
  if (!is.finite(lam_max) || lam_max <= 0) return(rep(0, nlambda))
  exp(seq(log(lam_max), log(lam_max * lambda_min_ratio), length.out = nlambda))
}

.block_folds_043 <- function(n, nf) {
  nf <- max(2L, min(as.integer(nf), n))
  rep(seq_len(nf), each = ceiling(n / nf))[seq_len(n)]
}

.fit_fista_043 <- function(X, Y, W, lambda, SigmaInv = NULL,
                           max_iter = 1500L, tol = 1e-6) {
  fista_lasso_multi_cpp(
    X = as.matrix(X), Y = as.matrix(Y), weights = as.matrix(W),
    lambda = as.numeric(lambda),
    SigmaInv = if (is.null(SigmaInv)) matrix(0, 0, 0) else as.matrix(SigmaInv),
    max_iter = as.integer(max_iter), tol = tol
  )
}

.cv_select_lambda_fista_043 <- function(X, Y, W, lambdas, SigmaInv = NULL,
                                        n_folds = 5L,
                                        max_iter = 1500L, tol = 1e-6) {
  X <- as.matrix(X); Y <- as.matrix(Y); W <- as.matrix(W)
  folds <- .block_folds_043(nrow(X), n_folds)
  cv <- numeric(length(lambdas))
  for (ii in seq_along(lambdas)) {
    ss <- 0
    for (ff in sort(unique(folds))) {
      tr <- which(folds != ff); va <- which(folds == ff)
      B <- .fit_fista_043(X[tr,,drop=FALSE], Y[tr,,drop=FALSE], W,
                          lambdas[ii], SigmaInv, max_iter, tol)
      R <- Y[va,,drop=FALSE] - X[va,,drop=FALSE] %*% B
      ss <- ss + if (is.null(SigmaInv)) sum(R^2) else sum((R %*% SigmaInv) * R)
    }
    cv[ii] <- ss
  }
  list(lambda = lambdas[which.min(cv)], cv = cv)
}

.adaptive_weights_043 <- function(B1, W0, adaptive_zero = c("finite", "active"),
                                  eps_w = 1e-8, cap_w = 1e6) {
  adaptive_zero <- match.arg(adaptive_zero)
  if (adaptive_zero == "finite") {
    W <- 1 / pmax(abs(B1), eps_w)
    W <- pmin(W, cap_w)
  } else {
    W <- matrix(Inf, nrow(B1), ncol(B1))
    nz <- abs(B1) > eps_w
    W[nz] <- 1 / abs(B1[nz])
  }
  W[W0 == 0] <- 0
  W
}

.cv_select_adaptive_nested_043 <- function(X, Y, W0, lambdas2, SigmaInv = NULL,
                                           n_folds = 5L, nlambda1 = 60L,
                                           lambda_min_ratio = 1e-4,
                                           max_iter = 1500L, tol = 1e-6,
                                           adaptive_zero = c("finite","active"),
                                           eps_w = 1e-8, cap_w = 1e6) {
  adaptive_zero <- match.arg(adaptive_zero)
  folds <- .block_folds_043(nrow(X), n_folds)
  cv <- numeric(length(lambdas2))
  for (ff in sort(unique(folds))) {
    tr <- which(folds != ff); va <- which(folds == ff)
    Xtr <- X[tr,,drop=FALSE]; Ytr <- Y[tr,,drop=FALSE]
    g1 <- .kkt_lambda_grid_fista_043(Xtr, Ytr, W0, SigmaInv,
                                     nlambda1, lambda_min_ratio)
    inner_folds <- min(n_folds, max(2L, floor(length(tr) / 5L)))
    lam1 <- .cv_select_lambda_fista_043(Xtr, Ytr, W0, g1, SigmaInv,
                                        inner_folds, max_iter, tol)$lambda
    B1 <- .fit_fista_043(Xtr, Ytr, W0, lam1, SigmaInv, max_iter, tol)
    W1 <- .adaptive_weights_043(B1, W0, adaptive_zero, eps_w, cap_w)
    Wfit <- W1; Wfit[!is.finite(Wfit)] <- 1e12
    for (ii in seq_along(lambdas2)) {
      B2 <- .fit_fista_043(Xtr, Ytr, Wfit, lambdas2[ii], SigmaInv, max_iter, tol)
      if (adaptive_zero == "active") B2[is.infinite(W1)] <- 0
      R <- Y[va,,drop=FALSE] - X[va,,drop=FALSE] %*% B2
      cv[ii] <- cv[ii] + if (is.null(SigmaInv)) sum(R^2) else sum((R %*% SigmaInv) * R)
    }
  }
  list(lambda = lambdas2[which.min(cv)], cv = cv)
}

#' Sparse VAR(p) via book-normalized Lasso and adaptive Lasso (FISTA)
#' @export
sVAR_adalasso_fista <- function(
    Yt, p = 1, fold = 5,
    penalize_diag = FALSE,
    standardize = TRUE,
    whiten = c("none", "diag", "full"),
    lambda = NULL,
    lambda_seq = NULL,
    lambda_rule = c("cv", "theory", "fixed"),
    theory_c = 1,
    nlambda = 100,
    lambda_min_ratio = 1e-4,
    max_iter = 1500,
    tol = 1e-6,
    adaptive_zero = c("finite", "active"),
    adaptive_cv = c("nested", "fixed_weights"),
    eps_w = 1e-8,
    cap_w = 1e6,
    debiasTF = FALSE,
    gam = 0.5,
    diagTF = NULL,
    updateSigma = NULL,
    sigma_diag_only = NULL) {

  penalize_diag <- .resolve_penalize_diag_043(penalize_diag, diagTF)
  whiten <- .resolve_whiten_043(whiten, updateSigma, sigma_diag_only)
  lambda_rule <- match.arg(lambda_rule)
  adaptive_zero <- match.arg(adaptive_zero)
  adaptive_cv <- match.arg(adaptive_cv)
  if (lambda_rule == "fixed" && is.null(lambda)) stop("lambda is required for lambda_rule='fixed'.")

  pre <- .svar_preprocess_043(Yt, p, standardize, whiten)
  q <- p * pre$k^2
  W0 <- .make_varp_weights_043(pre$k, p, penalize_diag)
  lam_pair <- if (is.null(lambda)) c(NA_real_, NA_real_) else {
    z <- as.numeric(lambda); if (length(z) == 1L) rep(z, 2L) else z[1:2]
  }

  grid1 <- if (is.null(lambda_seq)) {
    .kkt_lambda_grid_fista_043(pre$Xs, pre$Ys, W0, pre$SigmaInv,
                               nlambda, lambda_min_ratio)
  } else sort(unique(as.numeric(lambda_seq)), decreasing = TRUE)

  if (lambda_rule == "fixed") lam1 <- lam_pair[1]
  else if (lambda_rule == "theory") lam1 <- .theory_lambda_043(pre$N, q, theory_c)
  else lam1 <- .cv_select_lambda_fista_043(pre$Xs, pre$Ys, W0, grid1,
                                            pre$SigmaInv, fold, max_iter, tol)$lambda

  B1 <- .fit_fista_043(pre$Xs, pre$Ys, W0, lam1, pre$SigmaInv, max_iter, tol)
  W1 <- .adaptive_weights_043(B1, W0, adaptive_zero, eps_w, cap_w)
  Wfit <- W1; Wfit[!is.finite(Wfit)] <- 1e12

  grid2 <- if (is.null(lambda_seq)) {
    .kkt_lambda_grid_fista_043(pre$Xs, pre$Ys, Wfit, pre$SigmaInv,
                               nlambda, lambda_min_ratio)
  } else sort(unique(as.numeric(lambda_seq)), decreasing = TRUE)

  cv2 <- NULL
  if (lambda_rule == "fixed") lam2 <- lam_pair[2]
  else if (lambda_rule == "theory") lam2 <- .theory_lambda_043(pre$N, q, theory_c)
  else if (adaptive_cv == "nested") {
    zz <- .cv_select_adaptive_nested_043(
      pre$Xs, pre$Ys, W0, grid2, pre$SigmaInv,
      fold, min(nlambda, 60L), lambda_min_ratio,
      max_iter, tol, adaptive_zero, eps_w, cap_w)
    lam2 <- zz$lambda; cv2 <- zz$cv
  } else {
    zz <- .cv_select_lambda_fista_043(pre$Xs, pre$Ys, Wfit, grid2,
                                      pre$SigmaInv, fold, max_iter, tol)
    lam2 <- zz$lambda; cv2 <- zz$cv
  }

  B2 <- .fit_fista_043(pre$Xs, pre$Ys, Wfit, lam2, pre$SigmaInv, max_iter, tol)
  if (adaptive_zero == "active") B2[is.infinite(W1)] <- 0

  Phi_lasso <- diag(pre$Y_sd, pre$k) %*% t(B1) %*% diag(1 / pre$X_sd, pre$d)
  Phi_Alasso <- diag(pre$Y_sd, pre$k) %*% t(B2) %*% diag(1 / pre$X_sd, pre$d)
  Phi_ols <- VAR_ols(pre$Y_centered, p = p, eps = 1e-8)$Phi_hat

  out <- list(
    model = "sVAR", algo = "fista", profile = "book-0.4.3",
    objective = "book_1_over_N", lambda_scale = "book",
    Phi_hat_lasso = Phi_lasso, Phi_hat_Alasso = Phi_Alasso, Phi_hat_ols = Phi_ols,
    lambda_lasso = lam1, lambda_adalasso = lam2,
    lambdas_lasso = grid1, lambdas_adalasso = grid2, cv_adaptive = cv2,
    p = p, k = pre$k, N = pre$N, fold = fold,
    penalize_diag = penalize_diag, diagTF = !penalize_diag,
    standardize = standardize, whiten = whiten,
    updateSigma = !identical(whiten, "none"),
    sigma_diag_only = identical(whiten, "diag"),
    Sigma_hat = pre$Sigma_hat, SigmaInv = pre$SigmaInv, hal = pre$H,
    scales = list(X_sd = pre$X_sd, Y_sd = pre$Y_sd),
    adaptive_zero = adaptive_zero, adaptive_cv = adaptive_cv
  )

  if (isTRUE(debiasTF)) {
    out$Phi_hat_active <- sVAR_refit(Yt, Phi_Alasso, p, penalize_diag = penalize_diag)
    out$Phi_hat_relaxed <- gam * Phi_Alasso + (1 - gam) * out$Phi_hat_active
    out$gam <- gam
  }
  out
}

.diag_positions_043 <- function(k, p) {
  out <- vector("list", p)
  for (ell in seq_len(p)) out[[ell]] <- cbind(seq_len(k), (ell - 1L) * k + seq_len(k))
  do.call(rbind, out)
}

#' Hard threshold a sparse VAR estimate while respecting unpenalized self-lags
#' @export
sVAR_threshold <- function(x, eta = NULL, target = c("lasso", "adaptive"), factor = 1,
                           penalize_diag = NULL, p = NULL) {
  target <- match.arg(target)
  if (is.list(x) && !is.matrix(x)) {
    Phi <- if (target == "lasso") x$Phi_hat_lasso else x$Phi_hat_Alasso
    if (is.null(eta)) eta <- if (target == "lasso") x$lambda_lasso else x$lambda_adalasso
    if (is.null(penalize_diag) && !is.null(x$penalize_diag)) penalize_diag <- x$penalize_diag
    if (is.null(p) && !is.null(x$p)) p <- x$p
  } else {
    Phi <- as.matrix(x)
  }
  if (is.null(eta) || !is.finite(eta)) stop("A finite threshold eta is required.")
  if (is.null(penalize_diag)) penalize_diag <- FALSE
  if (is.null(p)) p <- max(1L, ncol(Phi) %/% nrow(Phi))
  out <- as.matrix(Phi)
  keep_diag <- NULL
  if (!isTRUE(penalize_diag)) {
    idx <- .diag_positions_043(nrow(out), p)
    keep_diag <- out[idx]
  }
  out[abs(out) < factor * eta] <- 0
  if (!isTRUE(penalize_diag)) out[idx] <- keep_diag
  out
}

#' Active-set refit for sparse VAR coefficients
#' @export
sVAR_refit <- function(Yt, Phi_hat, p = 1, eps = 1e-8, penalize_diag = FALSE) {
  Yc <- as.matrix(Yt) - rowMeans(as.matrix(Yt))
  des <- var_design(Yc, p)
  P <- as.matrix(Phi_hat)
  if (!isTRUE(penalize_diag)) {
    idx <- .diag_positions_043(nrow(P), p)
    P[idx] <- ifelse(P[idx] == 0, .Machine$double.eps, P[idx])
  }
  VAR_active_refit(des$X_design, des$Y_resp, P, eps)
}

#' Relaxed sparse VAR estimate
#' @export
sVAR_relax <- function(Yt, Phi_hat, p = 1, gamma = .5, eps = 1e-8,
                       penalize_diag = FALSE) {
  gamma * as.matrix(Phi_hat) + (1 - gamma) *
    sVAR_refit(Yt, Phi_hat, p, eps, penalize_diag)
}

#' Equation-wise scaled Lasso using Sun--Zhang universal baseline
#' @export
sVAR_scaled <- function(Yt, p = 1, lambda0 = NULL, theory_c = 1,
                        penalize_diag = FALSE,
                        standardize = TRUE, max_outer = 100L, max_iter = 2000L,
                        tol_outer = 1e-6, tol = 1e-7,
                        diagTF = NULL) {
  penalize_diag <- .resolve_penalize_diag_043(penalize_diag, diagTF)
  Yt <- as.matrix(Yt); k <- nrow(Yt); Yc <- Yt - rowMeans(Yt)
  des <- var_design(Yc, p); X <- as.matrix(des$X_design); Y <- as.matrix(des$Y_resp)
  N <- nrow(X); d <- ncol(X)

  X_sd <- rep(1, d); Y_sd <- rep(1, k); Xs <- X; Ys <- Y
  if (isTRUE(standardize)) {
    X_sd <- apply(X, 2, stats::sd); X_sd[!is.finite(X_sd) | X_sd <= 0] <- 1
    Y_sd <- apply(Y, 2, stats::sd); Y_sd[!is.finite(Y_sd) | Y_sd <= 0] <- 1
    Xs <- sweep(X, 2, X_sd, "/"); Ys <- sweep(Y, 2, Y_sd, "/")
  }
  if (is.null(lambda0)) lambda0 <- theory_c * sqrt(2 * log(max(d, 2L)) / N)

  B <- matrix(0, d, k); sigma <- rep(NA_real_, k); nit <- integer(k)
  for (j in seq_len(k)) {
    W <- matrix(1, d, 1)
    if (!isTRUE(penalize_diag)) for (ell in seq_len(p)) W[(ell - 1L) * k + j, 1] <- 0
    sj <- stats::sd(Ys[, j]); if (!is.finite(sj) || sj <= 1e-10) sj <- 1
    bj <- matrix(0, d, 1)
    for (it in seq_len(max_outer)) {
      # Canonical sparseVAR objective is RSS/N, hence 2*lambda0*sigma.
      lam <- 2 * lambda0 * sj
      bj_new <- .fit_fista_043(Xs, matrix(Ys[,j], ncol=1), W, lam,
                               SigmaInv = NULL, max_iter = max_iter, tol = tol)
      r <- Ys[,j] - Xs %*% bj_new
      sj_new <- sqrt(mean(r^2)); if (!is.finite(sj_new) || sj_new < 1e-10) sj_new <- 1e-10
      rel <- abs(sj_new - sj) / max(sj, 1e-10)
      bj <- bj_new; sj <- sj_new
      if (rel < tol_outer) break
    }
    B[,j] <- as.numeric(bj); sigma[j] <- sj; nit[j] <- it
  }
  Phi <- diag(Y_sd, k) %*% t(B) %*% diag(1 / X_sd, d)
  list(model = "sVAR", method = "scaled_lasso", Phi_hat = Phi,
       lambda0 = lambda0, sigma_hat = sigma,
       penalize_diag = penalize_diag, standardize = standardize,
       p = p, k = k, N = N, iterations = nit)
}

#' One-step debiased estimator
#' @export
sVAR_debias <- function(Yt, Phi_hat, p = 1,
                        inverse = c("auto", "exact", "ridge"), ridge = 1e-6, ...) {
  inverse <- match.arg(inverse)
  Yc <- as.matrix(Yt) - rowMeans(as.matrix(Yt)); des <- var_design(Yc, p)
  X <- as.matrix(des$X_design); Y <- as.matrix(des$Y_resp); N <- nrow(X)
  B <- t(as.matrix(Phi_hat)); G <- crossprod(X) / N
  chosen <- inverse
  if (inverse == "auto") chosen <- if (ncol(X) < N && qr(G)$rank == ncol(X)) "exact" else "ridge"
  M <- if (chosen == "exact") solve(G) else solve(G + ridge * diag(ncol(X)))
  score <- crossprod(X, Y - X %*% B) / N
  Bdb <- B + M %*% score
  list(Phi_hat = t(Bdb), M = M, inverse = chosen, score = score)
}

#' 0.4.3 book profile
#' @export
sVAR_book_control <- function() list(
  objective = "1/N", solver = "fista", cv = "blocked-min",
  adaptive_zero = "finite", adaptive_cv = "nested",
  whitening = "none", whiten = "none",
  penalize_diag = FALSE, standardize = TRUE,
  threshold_factor = 1, relax_gamma = .5,
  scaled_lambda0 = "sqrt(2*log(d)/N)"
)

#' Fit the eleven Chapter-1 sparse VAR estimators
#' @export
sVAR_variants <- function(
    Yt, p = 1, tuning = c("cv", "theory"), fold = 5, theory_c = 1,
    penalize_diag = FALSE,
    standardize = TRUE,
    whiten = c("none", "diag", "full"),
    threshold_factor = 1,
    relax_gamma = .5,
    scaled_lambda0 = NULL,
    nlambda = 80L,
    max_iter = 1500L,
    tol = 1e-6,
    adaptive_zero = c("finite", "active"),
    adaptive_cv = c("nested", "fixed_weights"),
    diagTF = NULL,
    updateSigma = NULL,
    sigma_diag_only = NULL) {
  tuning <- match.arg(tuning)
  adaptive_zero <- match.arg(adaptive_zero)
  adaptive_cv <- match.arg(adaptive_cv)
  penalize_diag <- .resolve_penalize_diag_043(penalize_diag, diagTF)
  whiten <- .resolve_whiten_043(whiten, updateSigma, sigma_diag_only)

  base <- sVAR_adalasso_fista(
    Yt = Yt, p = p, fold = fold,
    penalize_diag = penalize_diag, standardize = standardize,
    whiten = whiten, lambda_rule = tuning,
    theory_c = theory_c, nlambda = nlambda,
    max_iter = max_iter, tol = tol,
    adaptive_zero = adaptive_zero, adaptive_cv = adaptive_cv)

  L <- base$Phi_hat_lasso; A <- base$Phi_hat_Alasso
  Lref <- sVAR_refit(Yt, L, p, penalize_diag = penalize_diag)
  Aref <- sVAR_refit(Yt, A, p, penalize_diag = penalize_diag)
  Sc <- sVAR_scaled(Yt, p = p, lambda0 = scaled_lambda0, theory_c = theory_c,
                    penalize_diag = penalize_diag, standardize = standardize,
                    max_iter = max_iter, tol = tol)$Phi_hat

  list(
    model = "sVAR", profile = "book-0.4.3", tuning = tuning,
    methods = list(
      L = L,
      `L-Th` = sVAR_threshold(base, target = "lasso", factor = threshold_factor,
                              penalize_diag = penalize_diag, p = p),
      `L-Ref` = Lref,
      `L-Rlx` = relax_gamma * L + (1 - relax_gamma) * Lref,
      `L-Des` = sVAR_debias(Yt, L, p)$Phi_hat,
      A = A,
      `A-Th` = sVAR_threshold(base, target = "adaptive", factor = threshold_factor,
                              penalize_diag = penalize_diag, p = p),
      `A-Ref` = Aref,
      `A-Rlx` = relax_gamma * A + (1 - relax_gamma) * Aref,
      `A-Des` = sVAR_debias(Yt, A, p)$Phi_hat,
      ScL = Sc
    ),
    base_fit = base,
    control = modifyList(sVAR_book_control(), list(
      whiten = whiten,
      whitening = if (whiten == "none") "none" else paste0("one-step-", whiten),
      penalize_diag = penalize_diag,
      standardize = standardize,
      adaptive_zero = adaptive_zero,
      adaptive_cv = adaptive_cv,
      threshold_factor = threshold_factor,
      relax_gamma = relax_gamma))
  )
}
