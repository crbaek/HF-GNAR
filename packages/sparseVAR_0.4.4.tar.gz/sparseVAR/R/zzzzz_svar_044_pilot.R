# sparseVAR 0.4.4 pilot extension
# IMPORTANT: installed as R/zzzzz_svar_044_pilot.R so it is collated
# after R/zzzz_svar_043.R and becomes the public sVAR_adalasso_fista().
#
# Extends sVAR_adalasso_fista() with three adaptive-weight pilots:
#   pilot = "lasso" : existing sparseVAR 0.4.3 behavior (default)
#   pilot = "ridge" : blocked-CV ridge pilot
#   pilot = "ols"   : OLS when numerically full column rank; otherwise
#                     Moore-Penrose minimum-norm least squares.
#
# The stage-2 adaptive-lasso solver, preprocessing, lambda scaling, and
# back-transformation remain those of sparseVAR 0.4.3.

.svar_mp_solve_044 <- function(A, b) {
  A <- as.matrix(A)
  b <- as.matrix(b)
  ss <- svd(A, nu = nrow(A), nv = ncol(A))
  if (!length(ss$d) || max(ss$d) <= 0) {
    return(matrix(0, ncol(A), ncol(b)))
  }
  tol <- max(dim(A)) * max(ss$d) * .Machine$double.eps
  keep <- which(ss$d > tol)
  if (!length(keep)) {
    return(matrix(0, ncol(A), ncol(b)))
  }
  tmp <- crossprod(ss$u[, keep, drop = FALSE], b)
  tmp <- sweep(tmp, 1L, ss$d[keep], "/")
  ss$v[, keep, drop = FALSE] %*% tmp
}

.svar_ols_mp_pilot_044 <- function(X, Y) {
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  d <- ncol(X)

  if (!d) {
    return(list(
      B = matrix(0, 0L, ncol(Y)),
      rank = 0L,
      full_rank = TRUE,
      mp_used = FALSE,
      tol = NA_real_,
      sigma_max = NA_real_,
      sigma_min_kept = NA_real_,
      condition_kept = NA_real_
    ))
  }

  ss <- svd(X, nu = min(nrow(X), d), nv = d)

  if (!length(ss$d) || max(ss$d) <= 0) {
    return(list(
      B = matrix(0, d, ncol(Y)),
      rank = 0L,
      full_rank = FALSE,
      mp_used = TRUE,
      tol = 0,
      sigma_max = 0,
      sigma_min_kept = NA_real_,
      condition_kept = Inf
    ))
  }

  tol <- max(dim(X)) * max(ss$d) * .Machine$double.eps
  keep <- which(ss$d > tol)
  rk <- length(keep)

  if (!rk) {
    B <- matrix(0, d, ncol(Y))
    smin <- NA_real_
    cond <- Inf
  } else {
    tmp <- crossprod(ss$u[, keep, drop = FALSE], Y)
    tmp <- sweep(tmp, 1L, ss$d[keep], "/")
    B <- ss$v[, keep, drop = FALSE] %*% tmp
    smin <- min(ss$d[keep])
    cond <- max(ss$d[keep]) / smin
  }

  list(
    B = as.matrix(B),
    rank = rk,
    full_rank = (rk == d),
    mp_used = (rk < d),
    tol = tol,
    sigma_max = max(ss$d),
    sigma_min_kept = smin,
    condition_kept = cond
  )
}

.svar_ridge_grid_044 <- function(X, nlambda = 60L,
                                 lambda_min_ratio = 1e-6,
                                 lambda_max_ratio = 1e2) {
  X <- as.matrix(X)
  nlambda <- as.integer(nlambda)
  if (nlambda < 2L) stop("ridge_nlambda must be >= 2.")
  if (!is.finite(lambda_min_ratio) || lambda_min_ratio <= 0)
    stop("ridge_lambda_min_ratio must be positive.")
  if (!is.finite(lambda_max_ratio) || lambda_max_ratio <= lambda_min_ratio)
    stop("ridge_lambda_max_ratio must exceed ridge_lambda_min_ratio.")

  n <- max(1L, nrow(X))
  scale0 <- max(colSums(X^2) / n)
  if (!is.finite(scale0) || scale0 <= 0) scale0 <- 1

  lam_max <- scale0 * lambda_max_ratio
  lam_min <- scale0 * lambda_min_ratio
  exp(seq(log(lam_max), log(lam_min), length.out = nlambda))
}

.svar_ridge_fit_044 <- function(X, Y, lambda, W0) {
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  W0 <- as.matrix(W0)

  if (length(lambda) != 1L || !is.finite(lambda) || lambda < 0)
    stop("ridge lambda must be one nonnegative finite scalar.")
  if (!identical(dim(W0), c(ncol(X), ncol(Y))))
    stop("W0 has incompatible dimensions in ridge pilot.")

  d <- ncol(X)
  k <- ncol(Y)
  n <- nrow(X)
  XtX <- crossprod(X)
  XtY <- crossprod(X, Y)
  B <- matrix(0, d, k)

  for (j in seq_len(k)) {
    # W0 == 0 denotes coefficients exempt from penalization, e.g. self-lags.
    pen <- as.numeric(W0[, j] != 0)
    M <- XtX + (n * lambda) * diag(pen, d)
    rhs <- XtY[, j, drop = FALSE]

    bj <- tryCatch(
      solve(M, rhs),
      error = function(e) .svar_mp_solve_044(M, rhs)
    )
    B[, j] <- as.numeric(bj)
  }

  B
}

.svar_weighted_sse_044 <- function(R, SigmaInv = NULL) {
  R <- as.matrix(R)
  if (is.null(SigmaInv) || !length(SigmaInv)) {
    return(sum(R^2))
  }
  SigmaInv <- as.matrix(SigmaInv)
  sum((R %*% SigmaInv) * R)
}

.svar_ridge_cv_044 <- function(X, Y, W0, SigmaInv = NULL,
                               n_folds = 5L,
                               lambda = NULL,
                               lambda_seq = NULL,
                               nlambda = 60L,
                               lambda_min_ratio = 1e-6,
                               lambda_max_ratio = 1e2) {
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  n <- nrow(X)

  if (n < 3L) stop("Need at least 3 observations for ridge CV.")

  if (!is.null(lambda)) {
    lambda <- as.numeric(lambda)
    if (length(lambda) != 1L || !is.finite(lambda) || lambda < 0)
      stop("ridge_lambda must be a nonnegative finite scalar.")
    B <- .svar_ridge_fit_044(X, Y, lambda, W0)
    return(list(
      lambda = lambda,
      B = B,
      cv = NA_real_,
      lambda_seq = lambda,
      fixed = TRUE
    ))
  }

  if (is.null(lambda_seq)) {
    lambda_seq <- .svar_ridge_grid_044(
      X,
      nlambda = nlambda,
      lambda_min_ratio = lambda_min_ratio,
      lambda_max_ratio = lambda_max_ratio
    )
  } else {
    lambda_seq <- sort(unique(as.numeric(lambda_seq)), decreasing = TRUE)
    if (!length(lambda_seq) || any(!is.finite(lambda_seq)) || any(lambda_seq < 0))
      stop("ridge_lambda_seq must contain nonnegative finite values.")
  }

  nf <- min(as.integer(n_folds), n)
  if (nf < 2L) stop("Need at least two folds for ridge CV.")
  folds <- rep(seq_len(nf), each = floor(n / nf) + 1L)[seq_len(n)]

  cv <- numeric(length(lambda_seq))

  for (ii in seq_along(lambda_seq)) {
    lam <- lambda_seq[ii]
    sse <- 0

    for (ff in seq_len(nf)) {
      tr <- which(folds != ff)
      va <- which(folds == ff)
      if (!length(tr) || !length(va)) next

      B <- .svar_ridge_fit_044(
        X[tr, , drop = FALSE],
        Y[tr, , drop = FALSE],
        lam,
        W0
      )
      R <- Y[va, , drop = FALSE] - X[va, , drop = FALSE] %*% B
      sse <- sse + .svar_weighted_sse_044(R, SigmaInv)
    }

    cv[ii] <- sse
  }

  id <- which.min(cv)
  lam <- lambda_seq[id]
  B <- .svar_ridge_fit_044(X, Y, lam, W0)

  list(
    lambda = lam,
    B = B,
    cv = cv,
    lambda_seq = lambda_seq,
    fixed = FALSE
  )
}

.svar_pilot_fit_044 <- function(X, Y, W0, SigmaInv,
                                pilot = c("lasso", "ridge", "ols"),
                                lasso_B = NULL,
                                lasso_lambda = NA_real_,
                                fold = 5L,
                                ridge_lambda = NULL,
                                ridge_lambda_seq = NULL,
                                ridge_nlambda = 60L,
                                ridge_lambda_min_ratio = 1e-6,
                                ridge_lambda_max_ratio = 1e2) {
  pilot <- match.arg(pilot)

  if (pilot == "lasso") {
    if (is.null(lasso_B)) stop("Internal error: lasso pilot was not supplied.")
    return(list(
      B = as.matrix(lasso_B),
      method = "lasso",
      solver = "fista",
      lambda = as.numeric(lasso_lambda),
      rank = NA_integer_,
      full_rank = NA,
      mp_used = FALSE,
      condition = NA_real_,
      cv = NULL
    ))
  }

  if (pilot == "ridge") {
    z <- .svar_ridge_cv_044(
      X, Y, W0, SigmaInv,
      n_folds = fold,
      lambda = ridge_lambda,
      lambda_seq = ridge_lambda_seq,
      nlambda = ridge_nlambda,
      lambda_min_ratio = ridge_lambda_min_ratio,
      lambda_max_ratio = ridge_lambda_max_ratio
    )
    return(list(
      B = z$B,
      method = "ridge",
      solver = if (isTRUE(z$fixed)) "fixed-ridge" else "blocked-CV-ridge",
      lambda = z$lambda,
      rank = NA_integer_,
      full_rank = NA,
      mp_used = FALSE,
      condition = NA_real_,
      cv = list(values = z$cv, lambda_seq = z$lambda_seq)
    ))
  }

  z <- .svar_ols_mp_pilot_044(X, Y)
  list(
    B = z$B,
    method = "ols",
    solver = if (isTRUE(z$mp_used)) "moore-penrose" else "ols",
    lambda = NA_real_,
    rank = z$rank,
    full_rank = z$full_rank,
    mp_used = z$mp_used,
    condition = z$condition_kept,
    cv = NULL
  )
}

.svar_cv_adaptive_nested_pilot_044 <- function(
    X, Y, W0, grid2, SigmaInv,
    fold, max_iter, tol,
    adaptive_zero, eps_w, cap_w,
    pilot = c("ridge", "ols"),
    ridge_lambda = NULL,
    ridge_lambda_seq = NULL,
    ridge_nlambda = 60L,
    ridge_lambda_min_ratio = 1e-6,
    ridge_lambda_max_ratio = 1e2) {

  pilot <- match.arg(pilot)
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  n <- nrow(X)

  nf <- min(as.integer(fold), n)
  if (nf < 2L) stop("Need at least two outer folds for nested adaptive CV.")
  folds <- rep(seq_len(nf), each = floor(n / nf) + 1L)[seq_len(n)]

  cv <- numeric(length(grid2))

  for (ff in seq_len(nf)) {
    tr <- which(folds != ff)
    va <- which(folds == ff)
    if (!length(tr) || !length(va)) next

    if (pilot == "ridge") {
      # Select the ridge pilot inside the outer training fold.
      inner_nf <- min(nf, length(tr))
      if (inner_nf < 2L) stop("Not enough training observations for nested ridge pilot.")
      pp <- .svar_ridge_cv_044(
        X[tr, , drop = FALSE],
        Y[tr, , drop = FALSE],
        W0,
        SigmaInv,
        n_folds = inner_nf,
        lambda = ridge_lambda,
        lambda_seq = ridge_lambda_seq,
        nlambda = ridge_nlambda,
        lambda_min_ratio = ridge_lambda_min_ratio,
        lambda_max_ratio = ridge_lambda_max_ratio
      )
      Bp <- pp$B
    } else {
      Bp <- .svar_ols_mp_pilot_044(
        X[tr, , drop = FALSE],
        Y[tr, , drop = FALSE]
      )$B
    }

    W1 <- .adaptive_weights_043(
      Bp, W0, adaptive_zero, eps_w, cap_w
    )
    Wfit <- W1
    Wfit[!is.finite(Wfit)] <- 1e12

    for (ii in seq_along(grid2)) {
      B <- .fit_fista_043(
        X[tr, , drop = FALSE],
        Y[tr, , drop = FALSE],
        Wfit,
        grid2[ii],
        SigmaInv,
        max_iter,
        tol
      )
      R <- Y[va, , drop = FALSE] - X[va, , drop = FALSE] %*% B
      cv[ii] <- cv[ii] + .svar_weighted_sse_044(R, SigmaInv)
    }
  }

  list(
    lambda = grid2[which.min(cv)],
    cv = cv
  )
}

# Override sparseVAR 0.4.3 public function while retaining the exact lasso-pilot
# path as the default.
sVAR_adalasso_fista <- function(
    Yt, p = 1, fold = 5, penalize_diag = FALSE, standardize = TRUE,
    whiten = c("none", "diag", "full"), lambda = NULL, lambda_seq = NULL,
    lambda_rule = c("cv", "theory", "fixed"), theory_c = 1, nlambda = 100,
    lambda_min_ratio = 1e-4, max_iter = 1500, tol = 1e-6,
    adaptive_zero = c("finite", "active"),
    adaptive_cv = c("nested", "fixed_weights"),
    eps_w = 1e-8, cap_w = 1e6, debiasTF = FALSE, gam = 0.5,
    diagTF = NULL, updateSigma = NULL, sigma_diag_only = NULL,
    pilot = c("lasso", "ridge", "ols"),
    ridge_lambda = NULL,
    ridge_lambda_seq = NULL,
    ridge_nlambda = 60L,
    ridge_lambda_min_ratio = 1e-6,
    ridge_lambda_max_ratio = 1e2) {

  penalize_diag <- .resolve_penalize_diag_043(penalize_diag, diagTF)
  whiten <- .resolve_whiten_043(whiten, updateSigma, sigma_diag_only)
  lambda_rule <- match.arg(lambda_rule)
  adaptive_zero <- match.arg(adaptive_zero)
  adaptive_cv <- match.arg(adaptive_cv)
  pilot <- match.arg(pilot)

  if (lambda_rule == "fixed" && is.null(lambda))
    stop("lambda is required for lambda_rule='fixed'.")

  pre <- .svar_preprocess_043(Yt, p, standardize, whiten)
  q <- p * pre$k^2
  W0 <- .make_varp_weights_043(pre$k, p, penalize_diag)

  lam_pair <- if (is.null(lambda)) {
    c(NA_real_, NA_real_)
  } else {
    z <- as.numeric(lambda)
    if (length(z) == 1L) rep(z, 2L) else z[1:2]
  }

  # Companion lasso fit. This is unchanged from sparseVAR 0.4.3 and remains
  # available in Phi_hat_lasso even when ridge/OLS is used for adaptive weights.
  grid1 <- if (is.null(lambda_seq)) {
    .kkt_lambda_grid_fista_043(
      pre$Xs, pre$Ys, W0, pre$SigmaInv, nlambda, lambda_min_ratio
    )
  } else {
    sort(unique(as.numeric(lambda_seq)), decreasing = TRUE)
  }

  if (lambda_rule == "fixed") {
    lam1 <- lam_pair[1]
  } else if (lambda_rule == "theory") {
    lam1 <- .theory_lambda_043(pre$N, q, theory_c)
  } else {
    lam1 <- .cv_select_lambda_fista_043(
      pre$Xs, pre$Ys, W0, grid1, pre$SigmaInv,
      fold, max_iter, tol
    )$lambda
  }

  B1 <- .fit_fista_043(
    pre$Xs, pre$Ys, W0, lam1, pre$SigmaInv, max_iter, tol
  )

  # Pilot used only to construct adaptive weights.
  pilot_fit <- .svar_pilot_fit_044(
    pre$Xs, pre$Ys, W0, pre$SigmaInv,
    pilot = pilot,
    lasso_B = B1,
    lasso_lambda = lam1,
    fold = fold,
    ridge_lambda = ridge_lambda,
    ridge_lambda_seq = ridge_lambda_seq,
    ridge_nlambda = ridge_nlambda,
    ridge_lambda_min_ratio = ridge_lambda_min_ratio,
    ridge_lambda_max_ratio = ridge_lambda_max_ratio
  )
  Bpilot <- pilot_fit$B

  W1 <- .adaptive_weights_043(
    Bpilot, W0, adaptive_zero, eps_w, cap_w
  )
  Wfit <- W1
  Wfit[!is.finite(Wfit)] <- 1e12

  grid2 <- if (is.null(lambda_seq)) {
    .kkt_lambda_grid_fista_043(
      pre$Xs, pre$Ys, Wfit, pre$SigmaInv, nlambda, lambda_min_ratio
    )
  } else {
    sort(unique(as.numeric(lambda_seq)), decreasing = TRUE)
  }

  cv2 <- NULL

  if (lambda_rule == "fixed") {
    lam2 <- lam_pair[2]
  } else if (lambda_rule == "theory") {
    lam2 <- .theory_lambda_043(pre$N, q, theory_c)
  } else if (adaptive_cv == "nested") {
    if (pilot == "lasso") {
      # Exact 0.4.3 default path.
      zz <- .cv_select_adaptive_nested_043(
        pre$Xs, pre$Ys, W0, grid2, pre$SigmaInv, fold,
        min(nlambda, 60L), lambda_min_ratio,
        max_iter, tol, adaptive_zero, eps_w, cap_w
      )
    } else {
      zz <- .svar_cv_adaptive_nested_pilot_044(
        pre$Xs, pre$Ys, W0, grid2, pre$SigmaInv,
        fold, max_iter, tol,
        adaptive_zero, eps_w, cap_w,
        pilot = pilot,
        ridge_lambda = ridge_lambda,
        ridge_lambda_seq = ridge_lambda_seq,
        ridge_nlambda = ridge_nlambda,
        ridge_lambda_min_ratio = ridge_lambda_min_ratio,
        ridge_lambda_max_ratio = ridge_lambda_max_ratio
      )
    }
    lam2 <- zz$lambda
    cv2 <- zz$cv
  } else {
    zz <- .cv_select_lambda_fista_043(
      pre$Xs, pre$Ys, Wfit, grid2, pre$SigmaInv,
      fold, max_iter, tol
    )
    lam2 <- zz$lambda
    cv2 <- zz$cv
  }

  B2 <- .fit_fista_043(
    pre$Xs, pre$Ys, Wfit, lam2, pre$SigmaInv, max_iter, tol
  )

  if (adaptive_zero == "active")
    B2[is.infinite(W1)] <- 0

  Phi_lasso <- diag(pre$Y_sd, pre$k) %*%
    t(B1) %*% diag(1 / pre$X_sd, pre$d)
  Phi_pilot <- diag(pre$Y_sd, pre$k) %*%
    t(Bpilot) %*% diag(1 / pre$X_sd, pre$d)
  Phi_Alasso <- diag(pre$Y_sd, pre$k) %*%
    t(B2) %*% diag(1 / pre$X_sd, pre$d)

  # Backward-compatible legacy output. This helper has its historical tiny
  # stabilization; the true OLS/MP adaptive pilot is Phi_hat_pilot when
  # pilot = "ols".
  Phi_ols <- VAR_ols(
    pre$Y_centered, p = p, eps = 1e-8
  )$Phi_hat

  out <- list(
    model = "sVAR",
    algo = "fista",
    profile = "book-0.4.4",
    objective = "book_1_over_N",
    lambda_scale = "book",
    Phi_hat_lasso = Phi_lasso,
    Phi_hat_Alasso = Phi_Alasso,
    Phi_hat_ols = Phi_ols,
    Phi_hat_pilot = Phi_pilot,
    pilot = pilot,
    pilot_solver = pilot_fit$solver,
    pilot_rank = pilot_fit$rank,
    pilot_full_rank = pilot_fit$full_rank,
    pilot_mp_used = pilot_fit$mp_used,
    pilot_condition = pilot_fit$condition,
    lambda_pilot = pilot_fit$lambda,
    pilot_cv = pilot_fit$cv,
    lambda_lasso = lam1,
    lambda_adalasso = lam2,
    lambdas_lasso = grid1,
    lambdas_adalasso = grid2,
    cv_adaptive = cv2,
    p = p,
    k = pre$k,
    N = pre$N,
    fold = fold,
    penalize_diag = penalize_diag,
    diagTF = !penalize_diag,
    standardize = standardize,
    whiten = whiten,
    updateSigma = !identical(whiten, "none"),
    sigma_diag_only = identical(whiten, "diag"),
    Sigma_hat = pre$Sigma_hat,
    SigmaInv = pre$SigmaInv,
    hal = pre$H,
    scales = list(X_sd = pre$X_sd, Y_sd = pre$Y_sd),
    adaptive_zero = adaptive_zero,
    adaptive_cv = adaptive_cv
  )

  if (isTRUE(debiasTF)) {
    out$Phi_hat_active <- sVAR_refit(
      Yt, Phi_Alasso, p, penalize_diag = penalize_diag
    )
    out$Phi_hat_relaxed <- gam * Phi_Alasso +
      (1 - gam) * out$Phi_hat_active
    out$gam <- gam
  }

  out
}
