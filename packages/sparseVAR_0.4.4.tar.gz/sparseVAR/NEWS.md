# sparseVAR 0.4.4

## Adaptive-Lasso pilot selection

* `sVAR_adalasso_fista()` adds `pilot = c("lasso", "ridge", "ols")`.
* `lasso` preserves the 0.4.3 behavior and remains the default.
* `ridge` uses contiguous blocked cross-validation to choose its pilot penalty.
* `ols` uses ordinary least squares when numerically full rank and the
  Moore--Penrose minimum-norm solution when rank deficient.
* Pilot diagnostics are returned without changing the existing lasso and
  adaptive-lasso output names.

# sparseVAR 0.4.3

## Book-profile calibration

* Added `whiten = "none"` to the sparse-VAR FISTA/book interface.  The three
  supported choices are now `"none"`, `"diag"`, and `"full"`.
* The Chapter-1 book profile now defaults to `whiten = "none"` and
  `penalize_diag = FALSE`.  This matches the current simulation DGPs, whose
  own-lag diagonal coefficients are structurally nonzero.
* `standardize = TRUE` remains independent of whitening and remains the default.
* Hard thresholding now respects `penalize_diag = FALSE`: own-lag diagonal
  coefficients are left untouched by the post-threshold operation.
* Scaled Lasso uses the same diagonal-penalty convention as the Lasso family.
* Deprecated `diagTF`, `updateSigma`, and `sigma_diag_only` arguments are retained
  as compatibility aliases for migration of old scripts.

## Objective normalization

* FISTA uses the canonical `(1/N) RSS + lambda * penalty` objective, with gradient
  scaling `2/N`, consistent with the 0.4.2 book normalization.
* Scaled Lasso retains the Sun--Zhang baseline
  `lambda0 = theory_c * sqrt(2 log(d)/N)` and therefore uses
  `2 * lambda0 * sigma` in its internal FISTA beta update.
