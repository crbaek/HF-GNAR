// admm_source1.cpp
// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;

/* ============================================================
 * Utilities
 * ============================================================ */

inline void check_same_shape(const arma::mat& A, const arma::mat& B, const char* what) {
  if (A.n_rows != B.n_rows || A.n_cols != B.n_cols) {
    Rcpp::stop("%s: shape mismatch (%d x %d) vs (%d x %d)",
               what, (int)A.n_rows, (int)A.n_cols, (int)B.n_rows, (int)B.n_cols);
  }
}

/* ============================================================
 * VAR simulator & design matrix
 * ============================================================ */

// Simulate VAR: A is k x (k*p); Sigma is k x k; returns Y (k x T)
// [[Rcpp::export]]
arma::mat VAR_sim_cpp(int T, arma::mat A, arma::mat Sigma, int burn = 500) {
  int k = A.n_rows;
  int p = A.n_cols / k;
  int total = T + burn;

  if (A.n_cols != static_cast<arma::uword>(k * p)) Rcpp::stop("A must be k x (k*p)");
  if (Sigma.n_rows != static_cast<arma::uword>(k) || Sigma.n_cols != static_cast<arma::uword>(k))
  Rcpp::stop("Sigma must be k x k");

  arma::mat inno = arma::mvnrnd(arma::vec(k, arma::fill::zeros), Sigma, total).t();
  arma::mat init = arma::mvnrnd(arma::vec(k, arma::fill::zeros), Sigma, p).t();
  arma::mat Y(total, k, arma::fill::zeros);

  for (int r = 0; r < total; ++r) {
    arma::vec lagged(k * p);
    for (int j = 0; j < p; ++j) {
      lagged.subvec(j * k, (j + 1) * k - 1) = init.row(p - j - 1).t();
    }
    arma::rowvec y_row = (A * lagged).t() + inno.row(r);
    Y.row(r) = y_row;
    init.shed_row(0);
    init.insert_rows(p - 1, y_row);
  }
  return Y.rows(burn, total - 1).t(); // k x T
}

// Build VAR design from X (T x k): returns X_design ((T-p) x (k*p)) and Y ((T-p) x k)
// [[Rcpp::export]]
Rcpp::List create_var_design_matrix_cpp(const arma::mat& X, int p) {
  int n = X.n_rows;    // T
  int k = X.n_cols;
  if (n <= p) Rcpp::stop("Not enough rows for the given lag p");

  arma::mat X_design(n - p, k * p, arma::fill::zeros);
  for (int i = 0; i < p; ++i) {
    X_design.cols(i * k, (i + 1) * k - 1) = X.rows(p - i - 1, n - i - 2);
  }
  arma::mat Y = X.rows(p, n - 1);
  return Rcpp::List::create(Rcpp::Named("X_design") = X_design,
                            Rcpp::Named("Y")        = Y);
}

/* ============================================================
 * Soft-threshold (core + R-export wrapper)
 * ============================================================
 *
 *  - CORE: usable from C++ (optional arma::mat* mask pointer)
 *  - EXPORTED: soft_threshold_cpp(X, base_thr, M=NULL) for R,
 *              with M as Nullable<NumericMatrix>
 *  - Mask semantics: M==0 -> no L1 penalty at that entry; M==1 -> penalize.
 *  - Diagonals are NEVER thresholded (i==j are copied from X).
 */
// ---- CORE: soft-threshold with optional mask and diagonal toggle ----
static inline arma::mat soft_threshold_core(const arma::mat& X,
                                            const arma::mat& base_thr,
                                            const arma::mat* M_ptr = nullptr,
                                            const bool penalize_diag = true) {
  if (X.n_rows != base_thr.n_rows || X.n_cols != base_thr.n_cols) {
    Rcpp::stop("soft_threshold_core: X and base_thr must have identical shape.");
  }
  arma::mat thr_eff = base_thr;
  if (M_ptr != nullptr) {
    if (M_ptr->n_rows != X.n_rows || M_ptr->n_cols != X.n_cols) {
      Rcpp::stop("soft_threshold_core: M must have the same shape as X.");
    }
    thr_eff %= (*M_ptr); // zero threshold where M==0 -> no penalty
  }

  arma::mat out = X;
  for (arma::uword i = 0; i < X.n_rows; ++i) {
    for (arma::uword j = 0; j < X.n_cols; ++j) {
      if (!penalize_diag && i == j) continue; // keep diagonal untouched if flag = FALSE
      double val = X(i, j);
      double thr = thr_eff(i, j);
      double a   = std::abs(val) - thr;
      out(i, j)  = (a > 0.0) ? ((val >= 0.0 ? 1.0 : -1.0) * a) : 0.0;
    }
  }
  return out;
}

// ---- Exported wrapper for R (optional mask + diag toggle) ----
// [[Rcpp::export]]
arma::mat soft_threshold_cpp(const arma::mat& X,
                             const arma::mat& base_thr,
                             Rcpp::Nullable<Rcpp::NumericMatrix> M_opt = R_NilValue,
                             bool penalize_diag = true) {
  if (M_opt.isNotNull()) {
    Rcpp::NumericMatrix Mr(M_opt);
    arma::mat M(Mr.begin(), Mr.nrow(), Mr.ncol(), false);
    return soft_threshold_core(X, base_thr, &M, penalize_diag);
  } else {
    return soft_threshold_core(X, base_thr, nullptr, penalize_diag);
  }
}


/* ---------------- FISTA (unmasked) -------------------------- */

// [[Rcpp::export]]
arma::mat accelerated_proximal_gradient_adaptive_lasso(const arma::mat& X, const arma::mat& Y,
                                                       const arma::mat& weights, double lambda,
                                                       int max_iter = 1000, double tol = 1e-6,
                                                       double step_size = -1.0) {
  arma::uword d = X.n_cols, k = Y.n_cols;
  if (weights.n_rows != d || weights.n_cols != k) Rcpp::stop("weights must be d x k");

  arma::mat beta(d, k, fill::zeros), beta_prev(d, k, fill::zeros), y(d, k, fill::zeros);
  double t = 1.0, t_prev;
  arma::mat XtX = X.t() * X, XtY = X.t() * Y;

  if (step_size <= 0) {
    vec eigval = eig_sym(XtX);
    step_size = 1.0 / eigval(eigval.n_elem - 1);
  }
  arma::mat base_thr = lambda * weights * step_size;

  for (int iter = 0; iter < max_iter; ++iter) {
    beta_prev = beta;
    arma::mat gradient = XtX * y - XtY;
    arma::mat z = y - step_size * gradient;
    beta = soft_threshold_core(z, base_thr); // no mask

    double rel = norm(beta - beta_prev, "fro") / (norm(beta_prev, "fro") + tol);
    if (rel < tol) break;

    t_prev = t;
    t = (1.0 + std::sqrt(1.0 + 4.0 * t * t)) / 2.0;
    y = beta + ((t_prev - 1.0) / t) * (beta - beta_prev);
  }
  return beta;
}
