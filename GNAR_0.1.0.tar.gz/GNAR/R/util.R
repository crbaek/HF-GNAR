
quiet = function(x) {
  sink(tempfile())
  on.exit(sink())
  invisible(force(x))
}

getErr = function(true, cluster){
  N = length(true);
  # If label correctly
  a1 = sum((true - cluster)^2)/N;
  # If label conversely
  tt = -1*true +1;
  a2 = sum((tt - cluster)^2)/N;
  output = min(a1, a2); names(output) = c("groupME");
  return(output)
}

#' Compute parameter distance used in the simulation study (internal).
#' Frobenius norm
#' @keywords internal
#' @noRd
enorm = function(t,s){ sqrt(sum((t-s)^2)) }

#' Compute parameter distance used in the simulation study (internal).
#' Hamming distance on network
#' @keywords internal
#' @noRd
enorm0 = function(t,s){ sum((1*(t !=0) - 1*(s !=0))^2)}

#' Count the number of non-zero coeffcients.
#' 
#' @keywords internal
#' @noRd
enorm1 = function(t){ sum(1*(t !=0))}

#' Compute coefficient estimation errors for simulation study (internal).
#'
#' @keywords internal
#' @noRd
calcErr_coeff <- function(PhiHat, y, order, truePhi, K=2) {
  # Get method names from PhiHat
  method_names <- names(PhiHat)
  m <- length(PhiHat)
  q <- nrow(y)
  
  # Individual metrics
  Frob        <- unlist(lapply(PhiHat, enorm, s = truePhi))
  Hamming     <- unlist(lapply(PhiHat, enorm0, s = truePhi)) / (q * q)
  FrobNozero  <- unlist(lapply(PhiHat, function(hA1) {
    A = 1 * (truePhi != 0); sqrt(sum(A * (hA1 - truePhi)^2))
  }))
  L0          <- unlist(lapply(PhiHat, enorm1))
  Frobdiag    <- unlist(lapply(PhiHat, function(hA1) {
    A3 = diag(nrow(truePhi)); sqrt(sum(A3 * (hA1 - truePhi)^2))
  }))
  Froboffdiag <- unlist(lapply(PhiHat, function(hA1) {
    A2 = matrix(1, q, q); diag(A2) = 0; sqrt(sum(A2 * (hA1 - truePhi)^2))
  }))
  RSS         <- unlist(lapply(PhiHat, function(hA1) {
    out = VAR.sigma(y, hA1); sum(out$Resi^2)
  }))
  confusion   <- do.call(rbind, lapply(PhiHat, calculate_confusion, true = truePhi))
  
  # Assign proper names
  set_method_names <- function(vec, metric) {
    nm <- if (!is.null(method_names)) method_names else seq_along(vec)
    setNames(as.numeric(vec), paste0(nm, "_", metric))
  }
  named_Frob        <- set_method_names(Frob,        "Frob")
  named_Hamming     <- set_method_names(Hamming,     "Hamming")
  named_FrobNozero  <- set_method_names(FrobNozero,  "FrobNozero")
  named_L0          <- set_method_names(L0,          "L0")
  named_Frobdiag    <- set_method_names(Frobdiag,    "Frobdiag")
  named_Froboffdiag <- set_method_names(Froboffdiag, "Froboffdiag")
  named_RSS         <- set_method_names(RSS,         "RSS")
  
  # confusion matrix: accuracy, recall, precision, specificity, f1
  confusion_metrics <- c("accuracy", "recall", "precision", "specificity", "f1")
  named_confusion <- as.numeric(t(confusion))
  names(named_confusion) <- as.vector(outer(method_names, confusion_metrics, paste, sep = "_"))
  
  # Combine all
  return(c(
    named_Frob,
    named_Hamming,
    named_FrobNozero,
    named_L0,
    named_Frobdiag,
    named_Froboffdiag,
    named_RSS,
    named_confusion
  ))
}

#' Compute clustering misclassification error (internal).
#'
#' @keywords internal
#' @noRd
calcErr_cluster = function(estcluster, truecluster) {
  # Get method names from PhiHat
  method_names <- names(estcluster)
  m <- length(estcluster)
  P2 <- estcluster
  
  # Individual metrics
  mis         <- unlist(lapply(P2, getErr, cluster = truecluster))
  nmi         <- unlist(lapply(P2, calculate_nmi, labels2 = truecluster))
  
  # Assign proper names
  set_method_names <- function(vec, metric) {
    nm <- if (!is.null(method_names)) method_names else seq_along(vec)
    setNames(as.numeric(vec), paste0(nm, "_", metric))
  }
  named_mis         <- set_method_names(mis,         "mis")
  named_nmi         <- set_method_names(nmi,         "nmi")
  
  # Combine all
  return(c(named_mis, named_nmi))
}



#' Compute MSPE for a fitted VAR(1) coefficient matrix (internal).
#'
#' @keywords internal
#' @noRd
calcForecast = function(Ahat, train, testset, h=1){
  nt = ncol(testset)-h+1; d = nrow(train);
  er = numeric(nt); tr=train;
  for(i in 1:nt){
    yhat = VAR.forecast(y=tr, h=h, A = Ahat);
    er[i] = sum(yhat - testset[,i])^2;
    tr = cbind(tr, testset[,i])
  }
  return(mean(er)/d)  
}



#' Compute clustering NMI (internal).
#'
#' @keywords internal
#' @noRd
calculate_nmi <- function(labels1, labels2) {
  contingency_table <- table(labels1, labels2)
  
  # Calculate Mutual Information (MI)
  joint_prob <- contingency_table / sum(contingency_table)
  row_marginals <- rowSums(joint_prob)
  col_marginals <- colSums(joint_prob)
  
  mi <- sum(
    joint_prob[joint_prob > 0] * 
      log(joint_prob[joint_prob > 0] / (row_marginals %*% t(col_marginals))[joint_prob > 0])
  )
  
  # Calculate entropy
  entropy <- function(prob) {
    -sum(prob[prob > 0] * log(prob[prob > 0]))
  }
  
  h1 <- entropy(row_marginals)
  h2 <- entropy(col_marginals)
  
  # Calculate NMI
  #  nmi <- mi / sqrt(h1 * h2)
  nmi2 <- 2*mi / (h1 + h2)
  
  return(nmi2)
}

#' Compute confusion matrix beteen estiamted/true group (internal).
#'
#' @keywords internal
#' @noRd
calculate_confusion = function(estimated, true){
  
  A1 = 2*(estimated != 0)-1;
  A2 = 1*(true != 0); diag(A2) =1;
  
  confusion_matrix = matrix(0, 2, 2);
  A3= A2 - A1;
  TP = confusion_matrix[1,1] = sum(A3 ==0);
  FN = confusion_matrix[1,2] = sum(A3 ==2);
  FP = confusion_matrix[2,1] = sum(A3 == -1);
  TN = confusion_matrix[2,2] = sum(A3 == +1);
  
  # Calculate metrics
  accuracy <- (TP + TN) / sum(confusion_matrix)            # Accuracy
  recall <- TP / (TP + FN)                                 # Recall (Sensitivity)
  precision <- TP / (TP + FP)                              # Precision
  specificity <- TN / (TN + FP)                            # Specificity
  f1_score <- 2 * (precision * recall) / (precision + recall) # F1 Score
  
  out = c(accuracy, recall, precision, specificity, f1_score);
  names(out) = c("accuracy", "recall", "precision", "specificity", "f1")
  return(out)
}
