#' @useDynLib GNAR, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics abline points title
NULL
