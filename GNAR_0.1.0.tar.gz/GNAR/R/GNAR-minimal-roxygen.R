#' Individual GNAR Estimation Given a Chosen Initialization and Estimator
#'
#' Performs a single GNAR estimation pipeline where the user chooses
#' (i) an initial adjacency/network construction method and (ii) an estimation method
#' (least squares or MIP), with an optional MIP-based iterative refinement.
#'
#' The initial network can be one of:
#' \describe{
#'   \item{\code{"oracle"}}{Use the user-supplied oracle adjacency matrix \code{knownA}.}
#'   \item{\code{"SIS"}}{Sure-independence screening adjacency obtained from \code{getMarginal()}.}
#'   \item{\code{"BS"}}{Best-subset selection adjacency via \code{GNAR.bs()} with SIS warm start.}
#'   \item{\code{"AL"}}{Adaptive-lasso screening adjacency via \code{accPG_sVAR(type="adaptive")}.}
#' }
#'
#' For parameter estimation:
#' \describe{
#'   \item{\code{"LS"}}{Least-squares GNAR estimation given \code{A0} and initial groups.}
#'   \item{\code{"MIP"}}{MIP-based GNAR estimation via \code{GNAR.knownadjacency()}; if \code{imax > 1}
#'   and \code{init_net != "oracle"}, an additional MIP-iteration step via \code{GNAR_iterate_once()}.}
#' }
#'
#' **Note.** When \code{init_net = "oracle"}, the network is treated as fixed and no iterative
#' network updating is performed; a single MIP fit is returned.
#'
#' @param y A numeric matrix of dimension \code{d x T} (each row is a series/vertex).
#' @param p VAR lag order used in screening/estimation. Default is \code{1}.
#' @param knownA Oracle adjacency matrix (dimension \code{d x d}). Required when \code{init_net="oracle"}.
#' @param nk Sparsity level (number of selected edges in SIS/BS screening). Required for \code{"SIS"} and \code{"BS"}.
#' @param init_net Initial network method. One of \code{c("oracle","SIS","BS","AL")}.
#' @param est Estimation method. One of \code{c("LS","MIP")}.
#' @param imax Maximum number of iterations for the MIP-iteration routine. If \code{imax <= 1}, no iteration is done.
#' @param K Number of groups (communities). Default is \code{2}. (Current group initializer assumes \code{K=2} for 0/1 labels.)
#' @param Tlimit Time limit (seconds) for MIP/BS routines (passed to \code{GNAR.knownadjacency()} and \code{GNAR.bs()}).
#' @param ncore Number of cores used in BS/MIP routines (passed through).
#' @param verboseTF Logical; verbose output for MIP routines.
#' @param warmTF Logical; warm-start flag for MIP routines.
#' @param corrTF Logical; passed to \code{GNAR_iterate_once()} (if used).
#' @param plotTF Logical; passed to \code{GNAR_iterate_once()} (if used).
#'
#' @return A list with (at least) the following elements:
#' \describe{
#'   \item{\code{B}}{Estimated GNAR coefficient matrix (dimension \code{d x d}).}
#'   \item{\code{beta}}{Estimated grouped parameters (vector).}
#'   \item{\code{group}}{Estimated group labels (length \code{d}).}
#'   \item{\code{A_init}}{Initial adjacency matrix used for estimation.}
#'   \item{\code{group_init}}{Initial group labels used for LS/MIP estimation.}
#'   \item{\code{name}}{A short method label such as \code{"SIS-LS"}, \code{"BS-MIP-it"}, etc.}
#' }
#' For MIP fits, \code{status} (solver status) may also be included.
#'
#' @details
#' This function assumes the following functions are available in the package namespace:
#' \code{getMarginal}, \code{GNAR.bs}, \code{accPG_sVAR}, \code{GNAR.knownadjacency},
#' \code{GNAR_iterate_once}, \code{initialize_groups}, and \code{GNAR.fit}.
#' Some of these may require optional solvers (e.g., Gurobi) depending on your implementation.
#'
#' @examples
#' \dontrun{
#' ## Oracle network + single MIP fit
#' out1 <- GNAR.estimation(y, p=1, knownA=A_true, nk=200,
#'                         init_net="oracle", est="MIP")
#'
#' ## SIS initialization + LS
#' out2 <- GNAR.estimation(y, p=1, nk=200, init_net="SIS", est="LS")
#'
#' ## AL initialization + MIP iteration (imax=2)
#' out3 <- GNAR.estimation(y, p=1, nk=200, init_net="AL", est="MIP", imax=2)
#' }
#'
#' @export
GNAR.estimation <- function(
    y, p = 1,
    knownA = NULL, nk = NULL,
    init_net = c("oracle", "SIS", "BS", "AL"),
    est = c("LS", "MIP"),
    imax = 1,
    K = 2, Tlimit = 100, ncore = 1,
    verboseTF = FALSE, warmTF = TRUE,
    corrTF = FALSE, plotTF = FALSE
) {
  y <- as.matrix(y)
  init_net <- match.arg(init_net)
  est <- match.arg(est)

  if (init_net %in% c("SIS", "BS") && is.null(nk))
    stop("nk must be provided for SIS/BS methods.")
  if (init_net == "oracle" && is.null(knownA))
    stop("knownA must be provided for init_net = 'oracle'.")

  d <- nrow(y)

  ## --- 1) initial network A0 ---
  if (init_net == "oracle") {
    A0 <- 1L * (knownA != 0)
    diag(A0) <- 0L

  } else if (init_net == "SIS") {
    A0 <- getMarginal(dat1 = y, sp = nk, p = p)$SIS
    A0 <- 1L * (A0 != 0)
    diag(A0) <- 0L

  } else if (init_net == "BS") {
    SIS_A <- getMarginal(dat1 = y, sp = nk, p = p)$SIS
    SIS_A <- 1L * (SIS_A != 0)
    diag(SIS_A) <- 0L

    BS_out <- GNAR.bs(y = y, p = p, nk = nk, initB = SIS_A,
                      Tlimit = Tlimit, ncore = ncore)
    A0 <- 1L * (BS_out$bs0 != 0)
    diag(A0) <- 0L

  } else if (init_net == "AL") {
    fit_al <- accPG_sVAR(X = t(y), p = p, type = "adaptive")
    B_al <- fit_al$B
    A0 <- 1L * (B_al != 0)
    diag(A0) <- 0L
  }

  ## --- 2) initial groups (Zhu-style) ---
  group0 <- initialize_groups(B = A0, y = y, K = K)$zhu

  ## --- 3) estimation ---
  if (est == "LS") {
    fit <- GNAR.fit(y = y, A = A0, group = group0, p = p)
    group_hat <- initialize_groups(B = fit$B, y = y, K = K)$zhu

    return(list(
      B = fit$B, beta = fit$beta, group = group_hat,
      A_init = A0, group_init = group0,
      name = paste0(init_net, "-LS")
    ))
  }

  ## --- MIP estimation ---
  # For oracle, do NOT iterate / update network: single MIP is enough.
  fit0 <- GNAR.knownadjacency(
    y = y, p = p, nk = nk,
    knownA = A0,
    verboseTF = verboseTF, warmTF = warmTF,
    Tlimit = Tlimit, ncore = ncore
  )
  group_hat0 <- fit0$group[1, ]

  if (init_net == "oracle" || imax <= 1) {
    return(list(
      B = fit0$B, beta = fit0$beta, group = group_hat0,
      A_init = A0, group_init = group0,
      status = fit0$status,
      name = paste0(init_net, "-MIP")
    ))
  }

  ## --- MIP-it: MP only; network update only by MIP ---
  fit_it <- GNAR_iterate_once(
    A_init         = A0,
    group_init     = group_hat0,
    beta_init      = fit0$beta,
    method         = "MP",
    y              = y,
    nk             = nk,
    p              = p,
    K              = K,
    Tlimit         = Tlimit,
    imax           = imax,
    warmTF         = warmTF,
    verboseTF      = verboseTF,
    ncore          = ncore,
    corrTF         = corrTF,
    plotTF         = plotTF,
    network_method = "MIP"
  )

  fit_it$name <- paste0(init_net, "-MIP-it")
  fit_it$A_init <- A0
  fit_it$group_init <- group0
  fit_it
}



#' Fit GNAR using seven baseline methods
#'
#' Runs a collection of estimation procedures used in the GNAR simulation pipeline.
#' Given a training panel `y` and the oracle adjacency `knownA`, the function estimates
#' coefficient matrices and group memberships under several network initializations
#' (oracle / SIS / best-subset / adaptive lasso) and two estimation backends (LS / MIP).
#' It additionally runs an iterative refinement (`*-MIP-it`) where the network is updated
#' via a mixed-integer program (MIP) using the current group memberships and parameters.
#'
#' @param y Numeric matrix of dimension `d x T` (rows are series, columns are time).
#' @param p Autoregressive order. Currently the update routines are written for `p = 1`.
#' @param knownA Oracle adjacency matrix (`d x d`, 0/1). Required.
#' @param nk Integer sparsity budget (maximum number of directed edges). Required for SIS/BS updates.
#' @param K Number of latent groups/communities.
#' @param Tlimit Time limit (seconds) for each Gurobi MIP call.
#' @param ncore Number of threads used by Gurobi within each call (set to 1 when parallelizing outside).
#' @param imax Maximum number of refinement iterations for `*-MIP-it` procedures.
#' @param verboseTF Logical; if `TRUE`, print Gurobi output.
#' @param warmTF Logical; if `TRUE`, provide warm starts to MIP routines when available.
#' @param corrTF Logical; optional switch used by some initializers/diagnostics (kept for compatibility).
#' @param plotTF Logical; optional plotting switch (kept for compatibility).
#'
#' @return A named list with elements
#' `oracle-MIP`, `SIS-LS`, `BS-LS`, `AL-LS`, `SIS-MIP-it`, `BS-MIP-it`, `AL-MIP-it`.
#' Each element is a list containing at least:
#' \itemize{
#' \item `B`: estimated coefficient/adjacency-like matrix (model dependent),
#' \item `beta`: estimated grouped parameters,
#' \item `group`: estimated group memberships.
#' }
#'
#' @examples
#' set.seed(1)
#' d <- 10; TT <- 120
#' blockindex <- c(rep(0L, d/2), rep(1L, d - d/2))
#' cf <- c(phi11=0.3, phi12=0.1, phi21=0.1, phi22=0.25, nu1=0.2, nu2=0.1)
#' gen <- makephi_comm(q=d, B=matrix(0.4,2,2),
#'   phi11=cf[1], phi12=cf[2], phi21=cf[3], phi22=cf[4], beta1=cf[5], beta2=cf[6],
#'   blockindex=blockindex, selfTF=FALSE)
#' Y <- VAR_generator(TT, Phi=gen$Phi, Sigma=diag(d))
#' knownA <- 1L * (gen$Phi != 0)
#' nk <- sum(knownA != 0)
#' fit <- GNAR_7methods(y=Y, p=1, knownA=knownA, nk=nk, K=2, Tlimit=10, imax=1, ncore=1)
#'
#' @export
GNAR_7methods <- function(y, p = 1, knownA = NULL, nk = NULL,
                           K = 2, Tlimit = 100, ncore = 1, imax = 1,
                           verboseTF = FALSE, warmTF = TRUE,
                           corrTF = FALSE, plotTF = FALSE) {

  if (is.null(knownA)) stop("knownA must be provided (oracle adjacency matrix).")
  if (is.null(nk))     stop("nk (sparsity level) must be provided for SIS/BS methods.")

  d <- nrow(y)

  ## --- Initial networks: ORACLE / SIS / BS / AL ---
  A_oracle <- knownA

  SIS_A <- getMarginal(dat1 = y, sp = nk, p = p)$SIS

  BS_out <- GNAR.bs(y = y, p = p, nk = nk, initB = SIS_A,
                    Tlimit = Tlimit, ncore = ncore)
  BS_A <- BS_out$bs0

  fit_alasso <- accPG_sVAR(X = t(y), p = p, type = "adaptive")
  B_alasso  <- fit_alasso$B

  A_AL  <- 1L * (B_alasso != 0)  # includes diagonal as returned

  ## --- Initial groups (method of Zhu) ---
  group_SIS0    <- initialize_groups(B = SIS_A,    y = y, K = K)$zhu
  group_BS0     <- initialize_groups(B = BS_A,     y = y, K = K)$zhu
  group_AL0 <- initialize_groups(B = A_AL, y = y, K = K)$zhu

  est_oracle_MP <- GNAR.knownadjacency(
    y = y, p = p, knownA = A_oracle,
    verboseTF = verboseTF, Tlimit = Tlimit, ncore = ncore, warmTF = warmTF)
  group_oracle_MP <-  est_oracle_MP$group[1, ]

  est_SIS_LS <- GNAR.fit(y = y, A = SIS_A, group = group_SIS0, p = p)
  est_SIS_MP <- GNAR.knownadjacency(
    y = y, p = p, knownA = SIS_A,
    verboseTF = verboseTF, Tlimit = Tlimit, ncore = ncore, warmTF = warmTF
  )
  group_SIS_MP <-  est_SIS_MP$group[1, ]

  est_BS_LS <- GNAR.fit(y = y, A = BS_A, group = group_BS0, p = p)
  est_BS_MP <- GNAR.knownadjacency(
    y = y, p = p, knownA = BS_A,
    verboseTF = verboseTF, Tlimit = Tlimit, ncore = ncore, warmTF = warmTF
  )
  group_BS_MP <- est_BS_MP$group[1,]

  est_AL_LS <- GNAR.fit(y = y, A = A_AL, group = group_AL0, p = p)
  est_AL_MP <- GNAR.knownadjacency(
    y = y, p = p, knownA = A_AL,
    verboseTF = verboseTF, Tlimit = Tlimit, ncore = ncore, warmTF = warmTF
  )
  group_AL_MP  = est_AL_MP$group[1,]

  ## Now update the group for LS methods
  group_SIS    <- initialize_groups(B = est_SIS_LS$B,    y = y, K = K)$zhu;
  group_BS     <- initialize_groups(B = est_BS_LS$B,     y = y, K = K)$zhu;
  group_AL <- initialize_groups(B = est_AL_LS$B, y = y, K = K)$zhu;

  # --- All initial (non-iterated) results ---
  result_list <- list(
    "oracle-MIP"  = list(B = est_oracle_MP$B,  beta = est_oracle_MP$beta,  group = group_oracle_MP),
    "SIS-LS"     = list(B = est_SIS_LS$B,     beta = est_SIS_LS$beta,     group = group_SIS),
    "BS-LS"      = list(B = est_BS_LS$B,      beta = est_BS_LS$beta,      group = group_BS),
    "AL-LS"      = list(B = est_AL_LS$B,  beta = est_AL_LS$beta,  group = group_AL)
  )

  ## --- Iterative estimation: MP only, network updated only by MIP ---
  init_list <- c("SIS", "BS", "AL")

  for (init_name in init_list) {

    key <- paste0(init_name, "-MIP-it")

    A0 <- switch(init_name,
                 "SIS"    = SIS_A,
                 "BS"     = BS_A,
                 "AL" = A_AL)

    group0 <- switch(init_name,
                     "SIS"    = group_SIS,
                     "BS"     = group_BS,
                     "AL" = group_AL)

    beta0 <- switch(init_name,
                    "SIS"    = est_SIS_MP$beta,
                    "BS"     = est_BS_MP$beta,
                    "AL" = est_AL_MP$beta)

    result_list[[key]] <- GNAR_iterate_once(
      A_init        = A0,
      group_init    = group0,
      beta_init     = beta0,
      method        = "MP",        # only MP
      y             = y,
      nk            = nk,
      p             = p,
      K             = K,
      Tlimit        = Tlimit,
      imax          = imax,
      warmTF        = warmTF,
      verboseTF     = verboseTF,
      ncore         = ncore,
      corrTF        = corrTF,
      plotTF        = FALSE,
      network_method = "MIP"       # only MIP network update
    )
  }

  return(result_list)
}



GNAR_iterate_once <- function(
    A_init, group_init, beta_init, method, y, nk, p, K, Tlimit,
    imax = 5, warmTF = TRUE, verboseTF = FALSE, ncore = 1, corrTF = FALSE,
    plotTF = FALSE, network_method = c("MIP", "ALASSO")
) {
  B_cur <- A_init
  group_cur <- group_init
  beta_cur <- beta_init
  network_method <- match.arg(network_method)

  errold <- sum(VAR.sigma(y = y, hA1 = B_cur)$Resi^2)

  for (k in 1:imax) {

    if (network_method == "MIP") {
      res_phi <- GNAR.knowngroupphi(
        y = y, group = group_cur, cf = beta_cur, nk = nk,
        verboseTF = verboseTF, Tlimit = Tlimit, ncore = ncore
      )
      B_new <- res_phi$Z

    } else if (network_method == "ALASSO") {
      fit_alasso <- accPG_sVAR(X = t(y), p = p, type = "adaptive")
      B_alasso <- fit_alasso$B
      B_new <- 1L * (B_alasso != 0)   # adjacency exactly from adaptive-lasso pattern
    }

    # --- parameter estimation with the updated network ---
    if (method == "LS") {
      fit_new <- GNAR.fit(y = y, A = B_new, group = group_cur, p = p)
      B_new <- fit_new$B
      group_new <- initialize_groups(B = B_new, y = y, K = K)$zhu
      beta_new <- fit_new$beta

    } else if (method == "MP") {
      fit_new <- GNAR.knownadjacency(
        y = y, p = p, knownA = B_new,
        verboseTF = verboseTF, Tlimit = Tlimit, ncore = ncore, warmTF = warmTF
      )
      B_new <- fit_new$B
      beta_new <- fit_new$beta
      group_new <- fit_new$group[1, ]
    }

    errnew <- sum(VAR.sigma(y = y, hA1 = B_new)$Resi^2)
    relerr <- (errnew - errold) / errold
    if (relerr > -0.001) break

    B_cur <- B_new
    beta_cur <- beta_new
    group_cur <- group_new
    errold <- errnew
  }

  list(B = B_cur, beta = beta_cur, group = group_cur)
}

#### Core functions

GNAR.knownadjacency = function(y, p=1, nk=NULL, knownA=NULL, verboseTF=FALSE, warmTF=TRUE, Tlimit=2000, ncore=1){

  y = y - rowMeans(y);
  d = dim(y)[1];
  TT = dim(y)[2];
  T1 = TT-p;
  hal = diag(d);

  adjY = hal%*%y;
  adjX = adjY;

  ## Constructed in the row-wise fashion
  X2 = NULL;
  for (i in 1:p) {
    X2 = rbind(X2, adjX[, (p-i+1):(TT-i)]);
  }
  Y2 = adjY[, (p+1):TT];

  xty = as.vector(tcrossprod(Y2, X2))
  xtx =  Matrix(kronecker(tcrossprod(X2), diag(d)), sparse=TRUE)

  if (is.null(knownA) && is.null(nk)) {
    stop("You must provide either 'adj' or 'nk'.")
  }

  # If adj is given, compute nk
  if (!is.null(knownA) && is.null(nk)) {
    knownA = 1*(knownA !=0 );
    diag(knownA) = 1; nk = sum(knownA);
    diag(knownA) = 0;
  }

  aa = getMarginal(dat1=y, sp=nk, p=1)$SIS;
  ig = initialize_groups(B=aa, y=y, K=2);

  # If nk is given, compute adj
  if (!is.null(nk) && is.null(knownA)) {
    knownA = 1*(aa != 0);
    diag(knownA) = 0;
  }

  ### Initial estimates of the parameter phi_00,... phi_11, nu_1 and nu_2
  ### Initial estimates of the group
  ## Make sure A is indicator of zero/non-zero and diagonal is zero

  a1 = GNAR.fit(y=y, group=ig$zhu, A=knownA);

  ## initial estimated of B_ij
  best.beta = a1$B;
  b.upper = 1*as.vector(best.beta != 0)
  ## initial estimates of beta
  init.phi = a1$beta;
  ## because of the vectorizatio of nphi, phi_12 and phi_21 should be reversed..
  init.phi[c(2,3)] = init.phi[c(3,2)];

  id1 = which(ig$zhu ==1);
  id2 = which(ig$zhu ==0);
  zz.init = matrix(0, 2, d);
  zz.init[1, id1] = 1; zz.init[2, id2] = 1;


  ######################################################
  # HF starts here using Gurobi
  #####################################################
  # M = 2*max(abs(best.beta));
  ni = rowSums(knownA);
  M = .5;

  ## variables: b_ij (d*d), z_ik (2*d), beta (6)
  ## Linear constraints
  ## z_i1 + z_i2 = 1
  ## n_i * b_ij - phi_kl a_ij <= M( 2 -z_ik -z_jl)
  ## -M(2 -z_ik - z_jl) <= n_i * b_ij - phi_kl a_ij
  ## It equals to
  ## n_i b_ij  - phi_kl a_ij + M z_ik + M z_jl <= 2*M
  ## -n_i b_ij  + phi_kl a_ij + M z_ik + M z_jl <= 2*M
  ## Digagonals should satisfy
  ## b_ii - nu_1 + M z_i1 <= M,
  ## -b_ii + nu_1 + M z_i1 <= M
  ## b_ii - nu_2 + M z_i2 <= M,
  ## -b_ii + nu_2 + M z_i2 <= M


  bb = numeric(d*d); nphi = numeric(4); nv = numeric(2); zz = matrix(0, 2, d);

  C1 = NULL;
  for(i in 1:d){
    zz = matrix(0, 2, d);
    zz[,i] = 1;
    tmpz = c(bb, nphi, nv, as.vector(zz));
    C1 = as(rbind(C1, as.vector(tmpz)), "sparseMatrix");
  }


  C2 = C3 = NULL;
  for(i in 1:d){
    for(j in 1:d){
      if(i !=j && knownA[i,j] != 0){
        for(k in 1:2){
          for(l in 1:2){
            bmat = matrix(0, d, d); nphi = matrix(0, 2, 2); nv = numeric(2); zz = matrix(0, 2, d);
            bmat[i,j] = ni[i]; nphi[k,l] = knownA[i,j]; zz[k,i] = M; zz[l,j]=M;
            tmpc2 = c(as.vector(bmat), -1*as.vector(nphi), nv, as.vector(zz));
            tmpc3 = c(-1*as.vector(bmat), as.vector(nphi), nv, as.vector(zz));
            C2 = as(rbind(C2, as.vector(tmpc2)), "sparseMatrix");
            C3 = as(rbind(C3, as.vector(tmpc3)), "sparseMatrix");
          }
        }
      }
    }
  }

  if (is.null(C2)) {
    ncols <- d * d + 6 + 2 * d;
    C2 <- Matrix(0, nrow = 0, ncol = ncols, sparse = TRUE)
    C3 <- Matrix(0, nrow = 0, ncol = ncols, sparse = TRUE)
  }

  ## For the diagonals
  C4 = C5 = C6 = C7 = NULL;
  for(i in 1:d){
    bmat = matrix(0, d, d); nphi = matrix(0, 2, 2); zz = matrix(0, 2, d); nv = numeric(2);
    bmat[i,i] =1; nv[1] =1; zz[1,i] = M;
    tmpc4 = c(as.vector(bmat), as.vector(nphi), -1*nv, as.vector(zz));
    tmpc5 = c(-1*as.vector(bmat), as.vector(nphi), nv, as.vector(zz));

    zz = matrix(0, 2, d); nv = numeric(2); nv[2] =1; zz[2,i] = M;
    tmpc6 = c(as.vector(bmat), as.vector(nphi), -1*nv, as.vector(zz));
    tmpc7 = c(-1*as.vector(bmat), as.vector(nphi), nv, as.vector(zz));
    C4 = as(rbind(C4, as.vector(tmpc4)), "sparseMatrix");
    C5 = as(rbind(C5, as.vector(tmpc5)), "sparseMatrix");
    C6 = as(rbind(C6, as.vector(tmpc6)), "sparseMatrix");
    C7 = as(rbind(C7, as.vector(tmpc7)), "sparseMatrix");
  }


  model = params = list()
  model$A = suppressMessages(
    rbind(C1, C2, C3, C4, C5, C6, C7));

  model$sense = c(rep("=",nrow(C1)), rep("<=",2*nrow(C2)), rep("<=", 4*nrow(C4)));    # Last one is the sparsity
  model$rhs = c(rep(1, nrow(C1)), rep(2*M, 2*nrow(C2)), rep(M, 4*nrow(C4)));     # The vector b
  model$obj = c(-2*xty, rep(0, 6+d*2))     # The vector c in the objective
  model$Q = bdiag(xtx, Matrix(0, 6+d*2,  6+d*2))
  model$vtypes = c(rep("C",d*d), rep("C",6), rep("B", d*2)) # Variable type: cont or binary


  model$ub = c(b.upper, rep(1, 6), rep(1, d*2));
  model$lb =  c(rep(0, d*d), rep(0.05, 6), rep(0, d*2));
  if(warmTF){
    model$start = c(as.vector(best.beta), init.phi, as.vector(zz.init));
  }

  ### Checking wither starting satisfies the constrints
  ## ch = model$A %*% model$start - model$rhs
  params$MIPGap = 0.01     # Accept near-optimal
  params$Cuts = 2          # Try moderate cuts
  params$Presolve = 2      # Aggressive presolve
  params$Heuristics = 0.5  # Balance exploration
  params$TimeLimit = Tlimit
  params$Threads = ncore;
  if(verboseTF){
    gur.obj = gurobi(model,params);
  } else{
    gur.obj = quiet(gurobi(model,params));
  }
  cat(sprintf("Return status: %s.", gur.obj$status))

  if (is.null(gur.obj$x)) {
    gA = best.beta;
    beta = init.phi;
    gp = zz.init;
  } else{
    gA = matrix(gur.obj$x[1:(d*d)], d);
    ik = seq(from=d*d+1, to = d*d+6, by=1);
    beta = gur.obj$x[ik];
    beta[c(2,3)] = beta[c(3,2)];
    gp = matrix(gur.obj$x[-(1:(d*d+6))], ncol=d);
  }
  ## Output
  out =list();
  out$bs.obj=gur.obj;
  out$B = gA;
  out$beta = beta;
  out$group = gp;
  out$status = gur.obj$status;
  out$gnar = a1;
  return(out);
}

#' Update GNAR adjacency/weights given group memberships and parameters
#'
#' Implements the Step 3 network update for the GNAR simulation pipeline.
#' Two designs are supported:
#' \itemize{
#' \item `approxTF = TRUE`: legacy best-subset MIQP update (diagonal quadratic approximation, no row-normalization).
#' \item `approxTF = FALSE`: current MIP update with auxiliary variables `(xi_i, z_i)` as in the manuscript Step 3.
#' }
#'
#' @param y Numeric matrix `d x T` of time series (rows are nodes).
#' @param group Integer/binary vector of length `d` with group memberships (typically 0/1).
#' @param cf Numeric vector of length 6: `(phi11, phi12, phi21, phi22, nu1, nu2)`.
#' @param phi Deprecated alias for `cf` (kept for backward compatibility).
#' @param nk Sparsity budget (maximum number of directed edges).
#' @param Tlimit Time limit (seconds) for the solver.
#' @param stdTF Logical; if `TRUE`, use the group-specific scaling `phi_{g_i g_j}` in the regression design.
#' @param approxTF Logical; if `TRUE`, use legacy best-subset (approximate) network update.
#' @param verboseTF Logical; print solver output.
#' @param ncore Number of solver threads.
#' @param M Big-M constant used in linking constraints.
#' @param initA Optional warm-start matrix for the adjacency (or weights).
#' @param warmTF Logical; if `TRUE`, provide a warm start to the solver.
#'
#' @return A list with components:
#' \itemize{
#' \item `C`: estimated weight matrix,
#' \item `Z`: estimated adjacency (0/1),
#' \item `xi`, `z`: auxiliary variables (only meaningful when `approxTF = FALSE`),
#' \item `status`: solver status,
#' \item `result`: raw Gurobi result object.
#' }
#'
#' @export
GNAR.knowngroupphi <- function(
    y, group,
    cf = NULL, phi = NULL,            # 'phi' kept for backward compatibility
    nk = 10,
    Tlimit = 60,
    stdTF = TRUE,
    approxTF = FALSE,                 # <-- NEW: use best-subset (approx) update
    verboseTF = FALSE,
    ncore = 1,
    M = 1,
    initA = NULL,
    warmTF = FALSE,
    ...
) {
  if (is.null(cf)) cf <- phi
  if (is.null(cf) || length(cf) < 6) {
    stop("Provide 'cf' (length >= 6): (phi11, phi12, phi21, phi22, nu1, nu2).")
  }

  if (!requireNamespace("Matrix", quietly = TRUE)) stop("Package 'Matrix' is required.")
  if (!exists("gurobi")) stop("gurobi() not found. Please load the gurobi package.")

  d  <- nrow(y)
  TT <- ncol(y)
  if (length(group) != d) stop("'group' must have length d = nrow(y).")
  if (TT < 2) stop("Need at least 2 time points (VAR(1) update).")
  if (nk < 0) stop("'nk' must be nonnegative.")

  # --- data prep ---
  y <- y - rowMeans(y)
  y_lag  <- y[, 1:(TT - 1), drop = FALSE]
  y_curr <- y[, 2:TT,       drop = FALSE]

  nu_vec <- group * cf[5] + (1 - group) * cf[6]
  Y2 <- y_curr - nu_vec * y_lag

  # Precompute Gram matrices over t=1,...,T-1
  G <- y_lag %*% t(y_lag)    # d x d : sum_t y_{j,t-1} y_{k,t}
  H <- y_lag %*% t(Y2)       # d x d : sum_t y_{j,t-1} Y2_{i,t}

  d2 <- d * d

  # --- quadratic + linear objective (in c only) ---
  Q_blocks <- vector("list", d)
  obj_c <- numeric(d2)

  g  <- as.numeric(group)
  g0 <- 1 - g

  for (i in 1:d) {
    if (stdTF) {
      gi <- g[i]
      P_i <- gi * g  * cf[1] + gi * g0 * cf[2] +
             (1 - gi) * g  * cf[3] + (1 - gi) * g0 * cf[4]
    } else {
      P_i <- rep(1, d)
    }
    P_i[i] <- 0

    XtX_i <- Matrix::Matrix(tcrossprod(P_i) * G, sparse = TRUE)
    Q_blocks[[i]] <- 2 * XtX_i

    XtY_i <- as.numeric(P_i * H[, i])
    XtY_i[i] <- 0

    obj_c[((i - 1) * d + 1):(i * d)] <- -2 * XtY_i
  }

  Qc <- Matrix::bdiag(Q_blocks)

  # -------------------------------
  # Approx update: best-subset MIQP
  # -------------------------------
    # -------------------------------
  # Approx update: best-subset MIQP
  #   (matches the legacy BSS design:
  #    no row-normalization; diagonal quadratic term)
  # -------------------------------
  if (isTRUE(approxTF)) {

    nvar <- 2 * d2

    idx_c <- function(i, j) (i - 1L) * d + j
    idx_a <- function(i, j) d2 + idx_c(i, j)

    # Diagonal-only quadratic term:
    # Q_{(i,j),(i,j)} = 2 * sum_t (P_i[j] y_{j,t-1})^2 = 2 * (P_i[j]^2) * G[j,j]
    diagG <- diag(G)
    qdiag <- numeric(d2)

    # reuse g, g0 from above
    for (i in 1:d) {
      if (stdTF) {
        gi <- g[i]
        P_i <- gi * g  * cf[1] + gi * g0 * cf[2] +
               (1 - gi) * g  * cf[3] + (1 - gi) * g0 * cf[4]
      } else {
        P_i <- rep(1, d)
      }
      P_i[i] <- 0
      qdiag[((i - 1) * d + 1):(i * d)] <- 2 * (P_i^2) * diagG
    }

    obj <- c(obj_c, rep(0, d2))

    # Tiny tie-breaker to prefer fewer edges when objective ties
    eps_pen <- 1e-8
    for (i in 1:d) for (j in 1:d) if (i != j) obj[idx_a(i, j)] <- eps_pen

    Qc_diag <- Matrix::Diagonal(n = d2, x = qdiag)
    Q <- Matrix::bdiag(Qc_diag, Matrix::Matrix(0, d2, d2, sparse = TRUE))

    # bounds: allow negative c (as in legacy code lB = -0.1)
    lb <- c(rep(-0.1, d2), rep(0, d2))
    ub <- c(rep( 1.0, d2), rep(1, d2))

    vtypes <- c(rep("C", d2), rep("B", d2))

    # Fix diagonals: a_ii=0, c_ii=0
    for (i in 1:d) {
      lb[idx_c(i, i)] <- 0; ub[idx_c(i, i)] <- 0
      lb[idx_a(i, i)] <- 0; ub[idx_a(i, i)] <- 0
    }

    # Constraints:
    # 1) -M a_ij <= c_ij <= M a_ij  (i != j)
    # 2) global sparsity: sum_{i!=j} a_ij <= nk
    ii <- integer(0); jj <- integer(0); xx <- numeric(0)
    sense <- character(0); rhs <- numeric(0)
    r <- 0L

    add_row <- function(cols, vals, s, b) {
      r <<- r + 1L
      ii <<- c(ii, rep(r, length(cols)))
      jj <<- c(jj, cols)
      xx <<- c(xx, vals)
      sense <<- c(sense, s)
      rhs <<- c(rhs, b)
    }

    for (i in 1:d) {
      for (j in 1:d) {
        if (i == j) next
        # c_ij - M a_ij <= 0
        add_row(c(idx_c(i, j), idx_a(i, j)), c( 1, -M), "<=", 0)
        # -c_ij - M a_ij <= 0  <=> c_ij >= -M a_ij
        add_row(c(idx_c(i, j), idx_a(i, j)), c(-1, -M), "<=", 0)
      }
    }

    a_all <- (d2 + 1):(2 * d2)
    diag_idx <- d2 + sapply(1:d, function(i) idx_c(i, i))
    a_all_off <- setdiff(a_all, diag_idx)
    add_row(a_all_off, rep(1, length(a_all_off)), "<=", nk)

    A_mat <- Matrix::sparseMatrix(i = ii, j = jj, x = xx, dims = c(r, nvar))

    model <- list(
      A = A_mat,
      sense = sense,
      rhs = rhs,
      obj = obj,
      Q = Q,
      lb = lb,
      ub = ub,
      vtypes = vtypes
    )

    # warm start
    if (warmTF && !is.null(initA)) {
      A0 <- 1L * (initA != 0)
      diag(A0) <- 0L

      nnz <- sum(A0)
      if (nnz > nk) {
        w <- abs(initA)
        diag(w) <- -Inf
        ord <- order(as.vector(t(w)), decreasing = TRUE)
        keep <- ord[seq_len(nk)]
        A0_vec <- integer(d2)
        A0_vec[keep] <- 1L
        A0 <- matrix(A0_vec, nrow = d, byrow = TRUE)
        diag(A0) <- 0L
      }

      # C0: keep sign from initA but scale into [-0.1,1] and respect |c|<=M a
      C0 <- matrix(0, d, d)
      Cinit <- initA
      diag(Cinit) <- 0
      C0[A0 == 1L] <- pmax(pmin(Cinit[A0 == 1L], 1.0), -0.1)

      start <- numeric(nvar)
      start[1:d2] <- as.vector(t(C0))
      start[(d2 + 1):(2 * d2)] <- as.vector(t(A0))
      model$start <- start
    }

    params <- list(
      TimeLimit  = Tlimit,
      Threads    = ncore,
      MIPGap     = 0.01,
      Cuts       = 2,
      Presolve   = 2,
      Heuristics = 0.5
    )

    gur.obj <- if (verboseTF) gurobi(model, params) else quiet(gurobi(model, params))

    if (is.null(gur.obj$x)) {
      C_hat  <- matrix(0, d, d)
      A_hat  <- matrix(0, d, d)
    } else {
      x <- gur.obj$x
      C_hat <- matrix(x[1:d2], nrow = d, byrow = TRUE)
      A_hat <- matrix(x[(d2 + 1):(2 * d2)], nrow = d, byrow = TRUE)
    }

    diag(C_hat) <- 0
    diag(A_hat) <- 0
    Z_hat <- 1L * (A_hat > 0.5)

    return(list(
      C      = C_hat,
      Z      = Z_hat,
      xi     = rep(NA_real_, d),
      z      = as.numeric(rowSums(Z_hat) > 0),
      status = gur.obj$status,
      result = gur.obj
    ))
  }

  # -------------------------------------------
  # Default update: new MIP with (xi_i, z_i)
  # ------------------------------------------- new MIP with (xi_i, z_i)
  # -------------------------------------------
  nvar <- 2 * d2 + 2 * d

  idx_c  <- function(i, j) (i - 1L) * d + j
  idx_a  <- function(i, j) d2 + idx_c(i, j)
  idx_xi <- function(i) 2L * d2 + i
  idx_z  <- function(i) 2L * d2 + d + i

  obj <- c(obj_c, rep(0, nvar - d2))
  Q  <- Matrix::bdiag(Qc, Matrix::Matrix(0, nvar - d2, nvar - d2, sparse = TRUE))

  lb <- rep(0, nvar)
  ub <- rep(1, nvar)

  # c: continuous, a: binary, xi: continuous, z: binary
  vtypes <- c(rep("C", d2), rep("B", d2), rep("C", d), rep("B", d))

  # Fix diagonals: a_ii=0, c_ii=0
  for (i in 1:d) {
    lb[idx_c(i, i)] <- 0; ub[idx_c(i, i)] <- 0
    lb[idx_a(i, i)] <- 0; ub[idx_a(i, i)] <- 0
  }

  # --- constraints (sparse triplets) ---
  n_off <- d2 - d
  ncon  <- 4 * n_off + 3 * d + 1

  sense <- character(ncon)
  rhs   <- numeric(ncon)
  ii <- integer(0); jj <- integer(0); xx <- numeric(0)
  r <- 0L

  add_row <- function(cols, vals, s, b) {
    r <<- r + 1L
    ii <<- c(ii, rep(r, length(cols)))
    jj <<- c(jj, cols)
    xx <<- c(xx, vals)
    sense[r] <<- s
    rhs[r] <<- b
  }

  # (mip_adj_eqn2) and (mip_adj_eqn3): for i != j
  for (i in 1:d) {
    ic_i <- ((i - 1) * d + 1):(i * d)
    ia_i <- d2 + ic_i

    for (j in 1:d) {
      if (i == j) next

      ic  <- ic_i[j]
      ia  <- ia_i[j]
      ixi <- idx_xi(i)

      # -M a_ij <= c_ij <= M a_ij
      add_row(c(ic, ia), c( 1, -M), "<=", 0)
      add_row(c(ic, ia), c(-1, -M), "<=", 0)

      # -M(1-a_ij) <= c_ij - xi_i <= M(1-a_ij)
      # c_ij - xi_i + M a_ij <= M
      add_row(c(ic, ixi, ia), c( 1, -1,  M), "<=", M)
      # -c_ij + xi_i + M a_ij <= M
      add_row(c(ic, ixi, ia), c(-1,  1,  M), "<=", M)
    }
  }

  # (mip_adj_eqn4): sum_j c_ij = z_i
  for (i in 1:d) {
    ic_i <- ((i - 1) * d + 1):(i * d)
    add_row(c(ic_i, idx_z(i)), c(rep(1, d), -1), "=", 0)
  }

  # (mip_adj_eqn6): z_i <= sum_j a_ij <= (d-1) z_i
  for (i in 1:d) {
    ia_i <- (d2 + ((i - 1) * d + 1):(i * d))
    add_row(c(ia_i, idx_z(i)), c(rep(-1, d), 1), "<=", 0)
    add_row(c(ia_i, idx_z(i)), c(rep( 1, d), -(d - 1)), "<=", 0)
  }

  # (mip_adj_eqn5): global sparsity sum_{i,j} a_ij <= nk (diagonal already fixed to 0)
  a_all <- (d2 + 1):(2 * d2)
  diag_idx <- d2 + sapply(1:d, function(i) idx_c(i, i))
  a_all_off <- setdiff(a_all, diag_idx)
  add_row(a_all_off, rep(1, length(a_all_off)), "<=", nk)

  A_mat <- Matrix::sparseMatrix(i = ii, j = jj, x = xx, dims = c(ncon, nvar))

  model <- list(
    A      = A_mat,
    sense  = sense,
    rhs    = rhs,
    obj    = obj,
    Q      = Q,
    lb     = lb,
    ub     = ub,
    vtypes = vtypes
  )

  # --- warm start (optional) ---
  if (warmTF && !is.null(initA)) {
    A0 <- 1L * (initA != 0)
    diag(A0) <- 0L

    nnz <- sum(A0)
    if (nnz > nk) {
      w <- abs(initA)
      diag(w) <- -Inf
      ord <- order(as.vector(t(w)), decreasing = TRUE)
      keep <- ord[seq_len(nk)]
      A0_vec <- integer(d2)
      A0_vec[keep] <- 1L
      A0 <- matrix(A0_vec, nrow = d, byrow = TRUE)
      diag(A0) <- 0L
    }

    deg <- rowSums(A0)
    z0  <- as.numeric(deg > 0)
    xi0 <- ifelse(deg > 0, 1 / deg, 0)

    C0 <- matrix(0, d, d)
    for (i in 1:d) if (deg[i] > 0) C0[i, ] <- A0[i, ] * xi0[i]

    start <- numeric(nvar)
    start[1:d2] <- as.vector(t(C0))
    start[(d2 + 1):(2 * d2)] <- as.vector(t(A0))
    start[(2 * d2 + 1):(2 * d2 + d)] <- xi0
    start[(2 * d2 + d + 1):(2 * d2 + 2 * d)] <- z0
    model$start <- start
  }

  params <- list(
    TimeLimit  = Tlimit,
    Threads    = ncore,
    MIPGap     = 0.01,
    Cuts       = 2,
    Presolve   = 2,
    Heuristics = 0.5
  )

  gur.obj <- if (verboseTF) gurobi(model, params) else quiet(gurobi(model, params))

  if (is.null(gur.obj$x)) {
    C_hat  <- matrix(0, d, d)
    A_hat  <- matrix(0, d, d)
    xi_hat <- rep(0, d)
    z_hat  <- rep(0, d)
  } else {
    x <- gur.obj$x
    C_hat  <- matrix(x[1:d2], nrow = d, byrow = TRUE)
    A_hat  <- matrix(x[(d2 + 1):(2 * d2)], nrow = d, byrow = TRUE)
    xi_hat <- x[(2 * d2 + 1):(2 * d2 + d)]
    z_hat  <- x[(2 * d2 + d + 1):(2 * d2 + 2 * d)]
  }

  diag(C_hat) <- 0
  diag(A_hat) <- 0
  Z_hat <- 1L * (A_hat > 0.5)

  return(list(
    C      = C_hat,
    Z      = Z_hat,
    xi     = xi_hat,
    z      = z_hat,
    status = gur.obj$status,
    result = gur.obj
  ))
}

GNAR.bs = function(y, p=1, nk, initB, warmTF=TRUE, Tlimit=2000, ncore=1){

  y = y - rowMeans(y);
  d = dim(y)[1];
  TT = dim(y)[2];
  T1 = TT-p;
  hal = diag(d);

  adjY = hal%*%y;
  adjX = adjY;

  ## Constructed in the row-wise fashion
  X2 = NULL;
  for (i in 1:p) {
    X2 = rbind(X2, adjX[, (p-i+1):(TT-i)]);
  }
  Y2 = adjY[, (p+1):TT];

  xty = as.vector(tcrossprod(Y2, X2))
  xtx =  Matrix(kronecker(tcrossprod(X2), diag(d)), sparse=TRUE)

  hPA = hP0 = matrix(0, d, d*p);
  #####################################################
  # HF starts here using Gurobi
  #####################################################
  bestB = initB; ## Use SIS
  bigm = 2*max(abs(bestB))
  bestA = 1*(bestB != 0);
  diag(bestA) = 1; ## always include diagonal

  ## variables: b_ij, a_ij

  ## Linear constraints
  ## sparsity, b_ij - M a_ij <= 0
  ## -b_ij - M a_ij <= 0

  k=d*d; k1 = k-d; # Without diagonal entries, num of a_ij
  C1 = N1 = X1 = E1 = Z2 = NULL;

  for(j in 1:d){
    for(i in 1:d){
      if(i !=j){
        tmpC = Matrix(0, d, d);
        tmpC[i,j] = 1;
        C1 = as(rbind(C1, as.vector(tmpC)), "sparseMatrix");
      }
    }
  }

  rvec = c(rep(0, k), rep(1, k));

  ## Initialize values
  uA = matrix(1, d, d);
  uB = matrix(0, d, d); diag(uB) =1; #always include diagonal by setting lower bound to be 1
  nlow = floor(nk - 2*d); #lower bound for the number of sparsity

  model = params = list()
  model$A = suppressMessages(
    rbind(cbind(C1, -bigm*C1), #k1
          cbind(-1*C1, -bigm*C1), #k1
          rvec)
  );

  model$sense = c(rep("<=",2*k1), "=");    # Last one is the sparsity
  model$rhs = c(rep(0, 2*k1), nk);     # The vector b
  model$ub = c(rep(bigm, k), as.vector(uA));
  model$lb =  c(rep(-bigm, k), as.vector(uB));
  model$obj = c(-2*xty, rep(0, k))     # The vector c in the objective
  model$Q = bdiag(xtx, Matrix(0, k, k))
  model$vtypes = c(rep("C",k), rep("B",k)) # Variable type: cont or binary
  if(warmTF){
  model$start = c(as.vector(bestB), as.vector(bestA));}         # Warm start from GNAR

  params$TimeLimit = Tlimit
  params$Threads = ncore;
  gur.obj = quiet(gurobi(model,params))

  if (is.null(gur.obj$x)) {
    gA = bestB;
  } else{
    gA = matrix(gur.obj$x[1:k], d);
  }
    ig = initialize_groups(B=gA, y=y, K=2);
    out1=GNAR.fit(y, A=gA, group=ig$zhu, p=p);
  ## Output
  out =list();
  out$bs.obj=gur.obj;
  out$bs = gA;
  out$bs0 = out1$B; # bs+GNAR
  out$beta = out1$beta
  return(out);
}

#' Initialize group memberships from an estimated network
#'
#' Given an adjacency-like matrix (typically a binary support estimate), this helper computes
#' a low-dimensional embedding via a spectral-type procedure and applies a clustering step
#' (PAM/'blockbuster') to obtain group/community labels. In the simulation code, this is used
#' to assess community recovery by clustering the estimated adjacency pattern.
#'
#' @param A Numeric matrix of dimension `d x d`. Usually a binary matrix indicating estimated edges.
#' @param y Numeric matrix `d x T` used for optional preprocessing/standardization inside the initializer.
#' @param K Integer; number of groups/communities to extract.
#' @param symTF Logical; if `TRUE`, symmetrize `A` before the spectral step.
#' @param eps Small numeric constant used for numerical stability in normalization.
#'
#' @return A list with components:
#' \itemize{
#' \item `X_hat`: node embedding matrix of dimension `d x K`,
#' \item `buster`: integer vector of length `d` with estimated labels (implementation dependent),
#' \item `out.buster`: raw clustering object returned by `cluster::pam`.
#' }
#'
#' @details
#' This function is treated as an internal utility. To expose it in the package reference manual,
#' remove `@noRd` and add `@export`.
#'
#' @keywords internal
#' @noRd

initialize_groups = function(B, y, K=2){
  d = nrow(B); nst = floor(d/2); TT= ncol(y);
  ## individual moment for the diagonal entry of B
  ## fixed effect
  Ybar = rowMeans(y[,(2:TT)]);
  Ybar_lag1 = rowMeans(y[,-TT]);
  feff = Ybar - B%*%Ybar_lag1

  ## network effect
  vB = as.vector(B); vC = 0*vB;
  id = which(vB != 0);
  if( length(unique(vB[id])) > K*K ){
  out3 = kmeans(vB[id], centers=K*K, nstart=nst);
  vC[id] = out3$cluster
  C = matrix(vC, d, d); tilB = matrix(0, d, 4);
  for(i in 1:d){
    for(j in 1:4){
    idk = which(C[i,] == j)
    if(length(idk) >0){
      tilB[i,j] = sum(B[i,idk])/length(idk);
    } else{ tilB[i,j] = 0; }
    }
  }
  } else{
    tilB = NULL;
  }

    ## 2. Symmetrise coefficients
    PhiS = B + t(B); ## Works for VAR(1) now but can be extended to VAR(p)
    ## 3. SVD or sparseSVD
    svd_result <- svd(PhiS,nu=K,nv=K);
    ## 4. Standardize
    X_hat <- matrix(0, d, K);
    for(j in 1:d){
      X_hat[j,] <- svd_result$u[j,]/(base::norm(svd_result$u[j,],"2") + 1e-09);
    }

  out.buster = pam(X_hat, k=K); ## Blockbuster algorithm
  D = cbind(diag(B), feff, tilB);
  D1 = cbind(feff, tilB);
  ## Added scaling; not so necessary
  ## D = scale(D, center=FALSE, scale=TRUE)
  E = cbind(D, X_hat);
  fout1 = pam(D, k=K, nstart=nst) ## As in Zhu and Fan
  fout2 = pam(E, k=K, nstart=nst) ## For all combined
  fout3 = pam(D1, k=K, nstart=nst) ## fixed and network only
  ## Label as 1 and 0 for the group membership
  output = list();
  output$buster = 2-out.buster$clustering;
  output$zhu = 2-fout1$clustering;
  output$all = 2-fout3$clustering;
#  output$fn = fout3$clustering-1;
return(output)
}

getMarginal = function(dat1, sp, p=1){
  dat1 = dat1 - rowMeans(dat1);
  k = nrow(dat1);
  TT = dim(dat1)[2];
  T1 = TT-p;
  hal = diag(k);
  adjY = hal%*%dat1;

  ## Constructed in the row-wise fashion
  ## consistent with slide notation L and Y
  X2 = NULL;
  for (i in 1:p) {
    X2 = rbind(X2, adjY[, (p-i+1):(TT-i)]);
  }
  Y2 = adjY[, (p+1):TT];
  XtY = tcrossprod(Y2, X2);

  beta1 = as.vector(XtY)/rep(rowSums(X2^2), each=k)
  tB = matrix(beta1, k);

  out = list();
  out$marginal = tB;


  if(missing(sp)){ sp = k*k*p}
  ## SIS but include diagonal entry
  diag(tB) = max(abs(beta1));
  ids = order(abs(as.vector(tB)), decreasing=TRUE);
  sp1 = sp;
  beta1[-ids[1:sp1]] = 0;
  out$SIS = matrix(beta1, k);
  return(out)
}

#' Construct a GNAR coefficient matrix under a block/community design (internal).
#'
#' @keywords internal
#' @noRd
makephi_comm <- function(q, B, phi11, phi12, phi21, phi22, beta1, beta2, model="sbm", selfTF=FALSE, commsize, blockindex){

  ## commindex is 0 or 1 for community in SBM
  ## blockindex is 0 or 1 for group coefficients

  if(missing(commsize)){
    commsize = c(floor(q/2), q-floor(q/2));
  }

  if(missing(blockindex)){
    blockindex = c(rep(0, floor(q/2)), rep(1, q-floor(q/2)));
  }

  if(model == "sbm"){  ## This can be updated by using fastRG package if we want to generate more complex network
    sb <- sample_sbm(q, pref.matrix = B, block.sizes = commsize,
                     directed = TRUE, loops = selfTF);
  } else{
    sb = erdos.renyi.game(q, p=B, type="gnp", directed=TRUE, loops=selfTF);
  }

  A = as_adjacency_matrix(sb);
  tA = t(as.matrix(A));

  Q = matrix(0, q, q);
  for(i in 1:q){
    for(j in 1:q){
      if(blockindex[i] == 0 & blockindex[j] == 0){ Q[i,j] = phi11;}
      if(blockindex[i] == 0 & blockindex[j] == 1){ Q[i,j] = phi12;}
      if(blockindex[i] == 1 & blockindex[j] == 0){ Q[i,j] = phi21;}
      if(blockindex[i] == 1 & blockindex[j] == 1){ Q[i,j] = phi22;}
    }
  }

  Phi0 = tA*Q;
  D = rowSums(tA);
  Dh = diag(1/D);
  Dh[is.infinite(Dh)] = 0;
  Phi = Dh%*%Phi0;
  Phi[is.nan(Phi)] = 0; ## Make sure it returns zero if divided by zero
  Phi = Phi + diag(beta2*blockindex + beta1*(1-blockindex));

  # Outputs
  output=list()
  output$A = tA;
  output$Phi <- Phi;

  return(output)
}

getCoeff = function(coeff, y, group, A, p=1, diagTF=TRUE, returnTF=FALSE){
  # Check bounds and return large value if outside [0,1]
  if(any(coeff < 0) || any(coeff > 1)) {
    if(returnTF) {
      return(list(B = matrix(0, nrow=nrow(y), ncol=nrow(y)),
                  Resi = matrix(0, nrow=nrow(y), ncol=1),
                  RSS = 1e10))
    } else {
      return(1e10)  # Very large penalty value
    }
  }

  # Original function continues here
  TT = ncol(y); k=nrow(y);
  id1 = which(group == 1);
  id2 = which(group == 0);
  id = c(id1, id2);
  y1 = rbind(y[id1,], y[id2,]); ### Ordered y
  A = 1*(A !=0);
  A0 = A[id, id];
  diag(A0) = 0;
  W = diag(1/rowSums(A0));
  W[is.infinite(W)] = 0;
  A1 = W%*%A0;
  ng = sum(group);

  B1 = rbind(cbind(matrix(coeff[1], ng, ng), matrix(coeff[2], ng, k-ng)),
             cbind(matrix(coeff[3], k-ng, ng), matrix(coeff[4], k-ng, k-ng))
  );

  if(diagTF){
  B = B1*A1 + diag(c(rep(coeff[5], ng), rep(coeff[6], k-ng)));
  } else{
  B = B1*A1;
  }

  ## Calculate residuals
  ## Constructed in the row-wise fashion
  X2 = NULL;
  for (i in 1:p) {
    X2 = rbind(X2, y1[, (p-i+1):(TT-i)]);
  }
  Y2 = y1[, (p+1):TT];
  Resi = Y2 - B%*%X2;
  if(returnTF){
    out = list(); out$B = B; out$beta= coeff; out$Resi = Resi; out$RSS = sum(Resi^2);
  } else{
    out = sum(Resi^2);
  }
  return(out)
}

GNAR.fit = function(y, A, group, p=1, diagTF=TRUE, init=NULL){
  # A is adjacency matrix without diagonal term. It gives four coeff, phi11,phi12, phi21, phi22
  # Assuming mean is zero
  # Unordered case, so first order according to group then estimate parameters and put back
  # group membership is coded as 1 or 0
  TT = ncol(y); k = nrow(y);
  A = 1*(A != 0); diag(A) = 0;

  # Default initial values if not provided
  if(is.null(init)) {
    if(diagTF){
    initial_values <- c(0.2, 0, 0, 0.2, 0.1, 0.1)
    } else{
    initial_values <- c(0.2, 0, 0, 0.2, 0, 0)
    }
  } else{
  initial_values <- init}
  # Ensure initial values are within bounds
  initial_values <- pmax(0, pmin(1, initial_values))


  # First try with L-BFGS-B
  out_lbfgsb = tryCatch({
    optim(initial_values, getCoeff, y=y, group=group, A=A, diagTF=diagTF,
      method="L-BFGS-B", control=list(maxit=200, trace=FALSE, factr=1e12, pgtol=1e-4),
      lower=0, upper=1)
  }, error = function(e) {
    # Return a list with basic structure if L-BFGS-B fails completely
    list(par=initial_values, value=Inf, convergence=999)
  })

  # Get parameters from L-BFGS-B (ensure they're within bounds)
  lbfgsb_params = pmax(0, pmin(1, out_lbfgsb$par))

  # Now run Nelder-Mead with the L-BFGS-B result as starting point
  out_nm = optim(lbfgsb_params, getCoeff, y=y, group=group, A=A, diagTF=diagTF,
    method="Nelder-Mead", control=list(maxit=200, trace=FALSE, reltol=1e-8))
  beta = pmax(0, pmin(1, out_nm$par))

  # Calculate final results using Nelder-Mead output
  result = getCoeff(beta, y=y, group=group, A=A, p=p, diagTF=diagTF, returnTF=TRUE)
  Ahat = result$B
  ng = sum(group)
  id1 <- which(group == 1)
  id2 <- which(group == 0)
  Chat <- 0 * Ahat

  # Define id3 and id4 only if non-empty to avoid invalid indexing
  if (ng > 0) { id3 <- 1:ng; }
  if (ng < k) { id4 <- (ng + 1):k }

  if (length(id1) > 0 && ng > 0) {
    Chat[id1, id1] <- Ahat[id3, id3]
  }
  if (length(id1) > 0 && length(id2) > 0 && ng < k) {
    Chat[id1, id2] <- Ahat[id3, id4]
    Chat[id2, id1] <- Ahat[id4, id3]
  }
  if (length(id2) > 0 && ng < k) {
    Chat[id2, id2] <- Ahat[id4, id4]
  }

  # Include both optimization results for comparison
  output = list(
    B = Chat,
    Aordered = Ahat,
    beta = beta,
    group = group,
    out = out_nm,
    out_lbfgsb = out_lbfgsb,
    lbfgsb_value = out_lbfgsb$value,
    nm_value = out_nm$value,
    improvement = out_lbfgsb$value - out_nm$value,
    init_values = initial_values  # Include the initial values used
  )

  return(output)
}


VAR.sigma <- function (y, hA1) {
  k <- dim(y)[1]
  TT <- dim(y)[2]
  p <- dim(hA1)[2] / k
  T1 <- TT - p

  # Calculate residuals
  ## Constructed in the row-wise fashion
  X2 = NULL;
  for (i in 1:p) {
    X2 = rbind(X2, y[, (p-i+1):(TT-i)]);
  }
  Y2 = y[, (p+1):TT];
  Resi = Y2 - hA1%*%X2;

  # Estimate Sigma
  Sigma_z <- Resi %*% t(Resi) / TT
  out <- list()
  out$Resi <- Resi
  out$Sigma_z <- Sigma_z

  return(out)
}

#' Generate a VAR(1) sample given coefficient matrix and innovation covariance (internal).
#'
#' @keywords internal
#' @noRd
VAR_generator = function(TT, Phi, Sigma){

  q <- dim(Phi)[1];
  p <- dim(Phi)[2]/q;
  burn <- 500;

  innovations <- mvrnorm(n=TT+burn, rep(0, q), Sigma);
  init <- mvrnorm(n=p, rep(0, q), Sigma);
  init <- matrix(init, nrow=p);

  j <- 1;
  id <- seq(from= j+p-1, to = j, by=-1);

  Yt <- matrix(0, (TT+burn), q);
  for(t in 1:(TT+burn)){
    Yt[t,] <- Phi %*%as.vector(t(init[id,])) + innovations[t,];
    init <- rbind(init[-1,], Yt[t,]);
  }

  return(t(Yt[-(1:burn),]))
}


# =========================
# accPG (FISTA) solver
# =========================

#' Proximal Gradient (FISTA) Adaptive Lasso VAR with CV (diagonal toggle)
#'
#' Fits a sparse VAR(p) via accelerated proximal gradient (FISTA). The design
#' is standardized; results are returned on the original scale. Supports
#' adaptive-lasso weights and a diagonal non-penalization toggle.
#'
#' @param lambda L1 penalty; if missing, tuned by K-fold CV over
#'   \code{select_lambda_range()}.
#'
#' @return A list with:
#' \itemize{
#'   \item \code{B} coefficient matrix (original scale)
#'   \item \code{optimal_lambda}, \code{lambdas}, \code{cvout}
#'   \item \code{diagTF}, \code{k}, \code{p}, \code{scales}
#' }
#' @examples
#' \dontrun{
#' set.seed(2); X <- matrix(rnorm(300), 100, 3)
#' fit <- accPG_sVAR(X, p=2, type="adaptive", init="lasso", diagTF=TRUE)
#' }
#' @export
accPG_sVAR <- function(X, p, max_iter = 1000, type = "none",
                       lambda, tol = 1e-5, n_folds = 5,
                       diagTF = TRUE, init = c("ols","lasso")) {
  init <- match.arg(init)

  var_data <- create_var_design_matrix_cpp(X, p)
  X_design <- var_data$X_design
  Y        <- var_data$Y
  n <- nrow(X_design); k <- ncol(Y); d <- ncol(X_design)

  # Standardize with guards
  X_sd <- apply(X_design, 2, sd); X_sd[!is.finite(X_sd) | X_sd == 0] <- 1
  Y_sd <- apply(Y,        2, sd); Y_sd[!is.finite(Y_sd) | Y_sd == 0] <- 1
  X_scaled <- scale(X_design); Y_scaled <- scale(Y)

  # Weights (use `init`)
  if (type == "adaptive") {
    if (init == "ols") {
      eps <- 1e-8
      XtX <- crossprod(X_scaled)
      XtY <- crossprod(X_scaled, Y_scaled)
      B0  <- solve(XtX + diag(eps, ncol(XtX)), XtY)
      W <- 1 / (abs(B0) + 1e-8)
    } else { # lasso
      TT <- nrow(X_scaled)
      lam.theory <- 0.5 * TT * sqrt(2 * log(d)/max(TT-1,1))
      B0 <- accelerated_proximal_gradient_adaptive_lasso(
        X_scaled, Y_scaled, weights = matrix(1,d,k), lambda = lam.theory
      )
      W <- 1 / (abs(B0) + 1e-8)
    }
  } else {
    W <- matrix(1, d, k)
  }

  # Diagonal toggle: zero weights on main diagonal if requested
  if (isTRUE(diagTF)) {
    dd <- min(d, k)
    W[cbind(seq_len(dd), seq_len(dd))] <- 0
  }

  # CV if needed
  cv_prox <- function(lam) {
    folds <- rep(seq_len(n_folds), length.out = n)
    cv_err <- numeric(n_folds)
    for (ff in seq_len(n_folds)) {
      tr <- which(folds != ff); va <- which(folds == ff)
      Xtr <- X_scaled[tr,,drop=FALSE]; Ytr <- Y_scaled[tr,,drop=FALSE]
      Xva <- X_scaled[va,,drop=FALSE]; Yva <- Y_scaled[va,,drop=FALSE]
      Bsc <- accelerated_proximal_gradient_adaptive_lasso(
        Xtr, Ytr, weights = W, lambda = lam, max_iter = max_iter, tol = tol
      )
      cv_err[ff] <- mean((Yva - Xva %*% Bsc)^2)
    }
    sum(cv_err)
  }

  lambdas <- NULL; cvout <- NULL
  if (missing(lambda)) {
    lambdas <- select_lambda_range(X_scaled, Y_scaled)
    cvout   <- sapply(lambdas, cv_prox)
    lambda  <- lambdas[which.min(cvout)]
  }

  # Final fit
  B_scaled <- accelerated_proximal_gradient_adaptive_lasso(
    X_scaled, Y_scaled, weights = W, lambda = lambda, max_iter = max_iter, tol = tol
  )
  B <- diag(Y_sd, k, k) %*% t(B_scaled) %*% diag(1 / X_sd, d, d)

  list(
    B = B, optimal_lambda = lambda, cvout = cvout, lambdas = lambdas,
    diagTF = diagTF, k = k, p = d %/% k, scales = list(X_sd = X_sd, Y_sd = Y_sd)
  )
}


#' Forecasting VAR(p) model
#'
#' Forecast values by VAR(p)
#' @param y Multivariate Time series data
#' @param h length of time wanted to be forecasted
#' @param A coefficient matrix of model VAR
#' @keywords VAR forecast
#' @export

VAR.forecast <- function (y, h, A) {

  T1 <- dim(y)[2]
  k <- dim(A)[1]
  p <- dim(A)[2] / k

  # Find index for previous observations
  id <- seq(from = T1, to = T1 - p + 1, by = -1)

  Y1 <- Y <- matrix(0, k, h)
  for (r in 1:h) {
    Y[, r] <- A %*% as.vector(y[, id])
    Y1[, r] <- Y[, r]
    y <- cbind(y[, -1], Y[, r])
  }

  return(Y1) # Final data is k*T matrix
}

#' Custom lambda range selection function
#' @keywords internal

select_lambda_range <- function(X_design, Y) {
  # Calculate the maximum lambda based on the correlation between predictors and response
  max_correlation <- apply(X_design, 2, function(x) {
    max(abs(cor(x, Y)))
  })
  TT = nrow(Y);
  # Theoretical maximum lambda (when coefficient becomes zero)
  lambda_max <- .5*TT*max(max_correlation)
  # Minimum lambda (very small non-zero value)
  lambda_min <- min(1, .5*TT*lambda_max * 1e-4)
  # Create logarithmically spaced lambda sequence
  lambdas <- exp(seq(log(lambda_max), log(lambda_min), length.out = 100))
  return(lambdas)
}

